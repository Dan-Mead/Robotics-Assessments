import numpy as np
import trimesh
from time import time
from scipy import sparse
import matplotlib.pyplot as plt
import open3d as op

"""All code implemented as a joint effort by Aamal and Dan"""

mesh = trimesh.load('example_meshes/bunny.ply') # path to mesh, MUST BE .PLY
mesh_open = op.read_triangle_mesh('example_meshes/bunny.ply') # path to mesh, MUST BE .PLY
mesh_open.vertices = op.Vector3dVector(mesh.vertices)
mesh_open.vertex_normals = op.Vector3dVector(mesh.vertex_normals)
open_tree = op.KDTreeFlann(mesh_open)

start = time()

### Calculation of approximate uniform laplace

num_vertices = len(mesh.vertices)
num_faces = len(mesh.faces)

U_L = sparse.dok_matrix((num_vertices, num_vertices))

for i in range(len(mesh.vertices)):

    _, idx, _ = open_tree.search_knn_vector_3d(mesh_open.vertices[i], 6)  # find nearest neighbours of the vertex - these will be the actual neighbours

    neighbours = idx[1:]

    for j in neighbours:
        U_L[i,j] = 1
        U_L[j,i] = 1

U_L = sparse.csr_matrix(U_L)

N = sparse.csr_matrix.sum(U_L, axis = 1)

U_L = sparse.lil_matrix(U_L/N)

U_L.setdiag(-1)

t = (np.mean(mesh.edges_unique_length) ** 2) * 10e8 # min 1e2, properly work at 6-8

## Calculate delta array

deltas = np.zeros([len(mesh.vertices),1])

tail = np.argmax(mesh.vertices[:,1])
# snout = np.argmin(mesh.vertices[:,2])
# index = [tail]
# index = [6,23]
index = [6]

deltas[index] = 1

## Colour heat sources

# mesh.visual.vertex_colors = [255,255,255,255]
# mesh.visual.vertex_colors[index,:] = [0,0,0,255]
# # mesh.visual.vertex_colors[mesh.faces[index,:],:] = [0,0,0,255]
# mesh.show(smooth = False)

I = sparse.eye(len(mesh.vertices))

### Solve for u

ut = sparse.linalg.spsolve((I - t*U_L), deltas)

u = (ut - np.min(ut)) / (np.max(ut) - np.min(ut))

# Initialise the variables we'll need for later
div_X = np.zeros(len(mesh.vertices))
all_As = np.zeros(len(mesh.vertices)) # Barycentric cell areas


for i in range(len(mesh.vertices)):

    print((i / len(mesh.vertices)) * 100, '%') # progression monitor

    ### Create a mesh out of the neighbours of vertex i and then use this to create a KDTree
    search_mesh = op.TriangleMesh()

    vertices_indices = np.array(U_L[i].nonzero()[1])
    vertices_indices = np.delete(vertices_indices, (np.where(vertices_indices == i)[0]))

    search_mesh.vertices = op.Vector3dVector(mesh.vertices[vertices_indices])
    search_mesh.vertex_normals = op.Vector3dVector(mesh.vertex_normals[vertices_indices])

    search_tree = op.KDTreeFlann(search_mesh)

    for n in range(len(search_mesh.vertices)):
        # Each n is a neighbour of vertex i
        # Out of the other neighbours of i, find the two closest to neighbour n. Note that idx[0] is vertex n itself.
        # The other two neighbours (lets call them m1 and m2) will be used to form triangles i, n, m1 and i, n, m2
        _, idx, _ = search_tree.search_knn_vector_3d(search_mesh.vertices[n], 3)

        # For m1:
        # Find the values of ut which correspond to those vertices. These are ordered so that i is u3, the is u2 and m1 is u1

        # Here, we will try to figure out which way the points in the triangle are ordered so that we're always going counter clockwise
        mid = search_mesh.vertices[idx[1]] + search_mesh.vertices[idx[0]]
        mid_strike = mesh.vertices[i] - mid/2
        mid_strike /= np.linalg.norm(mid_strike)
        mid = search_mesh.vertices[idx[1]] - search_mesh.vertices[idx[0]]
        mid /= np.linalg.norm(mid)

        # Average vertex normals to get face normal
        N = (np.asarray(search_mesh.vertex_normals)[idx[0]] + np.asarray(search_mesh.vertex_normals)[idx[1]] + mesh.vertex_normals[i]) / 3

        dir = np.dot(mid, np.cross(N, mid_strike))

        if dir > 0:

            uf = ut[[vertices_indices[idx[1]], vertices_indices[idx[0]], i]]

            # The order here should align with the u values from above
            e1 = search_mesh.vertices[idx[0]] - mesh.vertices[i]
            e2 = mesh.vertices[i] - search_mesh.vertices[idx[1]]
            e3 = search_mesh.vertices[idx[1]] - search_mesh.vertices[idx[0]]

            # Here we calculate the grad u vector for each triangle
            cross = np.array([np.cross(N, e1), np.cross(N, e2), np.cross(N, e3)])
            Af = np.linalg.norm(0.5 * np.cross(e1, -e2))

            # Dot product here is essentially to replace the sum over all i
            grad_u = np.dot(uf, cross) / (2 * Af)
            X = grad_u/np.linalg.norm(grad_u)

            # These are supposed to match with the e1 and e2 definitions from the paper.
            cot_theta_1 = 1 / (np.tan(np.arccos(np.dot(e2, -e3) / (np.linalg.norm(e2) * np.linalg.norm(e3)))))
            cot_theta_2 = 1 / (np.tan(np.arccos(np.dot(-e1, e3) / (np.linalg.norm(e1) * np.linalg.norm(e3)))))

            div_X[i] += cot_theta_1 * np.dot(e1, X) + cot_theta_2 * np.dot(-e2, X)

        else:

            uf = ut[[vertices_indices[idx[0]], vertices_indices[idx[1]], i]]

            e1 = search_mesh.vertices[idx[1]] - mesh.vertices[i]
            e2 = mesh.vertices[i] - search_mesh.vertices[idx[0]]
            e3 = search_mesh.vertices[idx[0]] - search_mesh.vertices[idx[1]]

            # Here we calculate the grad u vector for each triangle
            cross = np.array([np.cross(N, e1), np.cross(N, e2), np.cross(N, e3)])
            Af = np.linalg.norm(0.5 * np.cross(e1, -e2))
            grad_u = np.dot(uf, cross) / (2 * Af)
            X = grad_u/np.linalg.norm(grad_u)

            # These are supposed to match with the e1 and e2 definitions from the paper.
            cot_theta_1 = 1 / (np.tan(np.arccos(np.dot(e2, -e3) / (np.linalg.norm(e2) * np.linalg.norm(e3)))))
            cot_theta_2 = 1 / (np.tan(np.arccos(np.dot(-e1, e3) / (np.linalg.norm(e1) * np.linalg.norm(e3)))))

            div_X[i] += cot_theta_1 * np.dot(e1, X) + cot_theta_2 * np.dot(-e2, X)

        # Repeat the process for m2

        mid = search_mesh.vertices[idx[2]] + search_mesh.vertices[idx[0]]
        mid_strike = mesh.vertices[i] - mid/2
        mid_strike /= np.linalg.norm(mid_strike)
        mid = search_mesh.vertices[idx[2]] - search_mesh.vertices[idx[0]]
        mid /= np.linalg.norm(mid)

        # Average vertex normals to get face normal
        N = (np.asarray(search_mesh.vertex_normals)[idx[0]] + np.asarray(search_mesh.vertex_normals)[idx[2]] +
             mesh.vertex_normals[i]) / 3

        dir = np.dot(mid, np.cross(N, mid_strike))
        if dir > 0:

            uf = ut[[vertices_indices[idx[2]], vertices_indices[idx[0]], i]]

            # The order here should align with the u values from above
            e1 = search_mesh.vertices[idx[0]] - mesh.vertices[i]
            e2 = mesh.vertices[i] - search_mesh.vertices[idx[2]]
            e3 = search_mesh.vertices[idx[2]] - search_mesh.vertices[idx[0]]

            # Here we calculate the grad u vector for each triangle
            cross = np.array([np.cross(N, e1), np.cross(N, e2), np.cross(N, e3)])
            Af = np.linalg.norm(0.5 * np.cross(e1, -e2))
            grad_u = np.dot(uf, cross) / (2 * Af)
            X = grad_u / np.linalg.norm(grad_u)

            # These are supposed to match with the e1 and e2 definitions from the paper.
            cot_theta_1 = 1 / (np.tan(np.arccos(np.dot(e2, -e3) / (np.linalg.norm(e2) * np.linalg.norm(e3)))))
            cot_theta_2 = 1 / (np.tan(np.arccos(np.dot(-e1, e3) / (np.linalg.norm(e1) * np.linalg.norm(e3)))))

            div_X[i] += cot_theta_1 * np.dot(e1, X) + cot_theta_2 * np.dot(-e2, X)

        else:

            uf = ut[[vertices_indices[idx[0]], vertices_indices[idx[2]], i]]

            e1 = search_mesh.vertices[idx[2]] - mesh.vertices[i]
            e2 = mesh.vertices[i] - search_mesh.vertices[idx[0]]
            e3 = search_mesh.vertices[idx[0]] - search_mesh.vertices[idx[2]]

            # Here we calculate the grad u vector for each triangle
            cross = np.array([np.cross(N, e1), np.cross(N, e2), np.cross(N, e3)])
            Af = np.linalg.norm(0.5 * np.cross(e1, -e2))
            grad_u = np.dot(uf, cross) / (2 * Af)
            X = grad_u / np.linalg.norm(grad_u)

            # These are supposed to match with the e1 and e2 definitions from the paper.
            cot_theta_1 = 1 / (np.tan(np.arccos(np.dot(e2, -e3) / (np.linalg.norm(e2) * np.linalg.norm(e3)))))
            cot_theta_2 = 1 / (np.tan(np.arccos(np.dot(-e1, e3) / (np.linalg.norm(e1) * np.linalg.norm(e3)))))

            div_X[i] += cot_theta_1 * np.dot(e1, X) + cot_theta_2 * np.dot(-e2, X)

div_X = div_X/4

U_L = sparse.csr_matrix(U_L)

## Solve for Phi

phi = sparse.linalg.spsolve(U_L, div_X)
phi = (phi - min(phi))/(max(phi) - min(phi))
# phi = (phi - min(phi))

mesh.visual.vertex_colors[:] = [255, 255, 255, 255]
Inferno = plt.get_cmap('inferno_r')
colours = Inferno(phi) * 255
mesh.visual.vertex_colors = colours

print(time() - start, 'seconds')

mesh.visual.vertex_colors[index] = [0, 0, 0, 255]
mesh.show()

# ## extra variable plotting code
# plot_var = np.sort(phi, axis = 0)
# # plot_var = phi
#
# plt.plot(np.arange(len(plot_var)), plot_var, 'x')
# # plt.hist(plot_var, bins = 10000)
# plt.show()



