import trimesh
import matplotlib.pyplot as plt
import numpy as np
import scipy as sp
import time

"""All code implemented as a joint effort by Aamal and Dan"""

### Import Model, Example_Meshes generally have less points

path = 'C:/Users/danme/Desktop/PyCharm Projects/3D/Project/Meshes/bunny.obj' # path to mesh, change as required, .obj preferred

print('Imported')

mesh = trimesh.load_mesh(path)
if path == 'C:/Users/danme/Desktop/PyCharm Projects/3D/Project/Meshes/tyra.obj':
    mesh.invert() # only necessary for some inverted meshes, change path as appropriate

### Preliminary Colouring (Optional) colour in specific vertices etc.

# mesh.visual.vertex_colors = [255,255,255,255]
# mesh.visual.vertex_colors[index,:] = [0,0,0,255]
# mesh.visual.vertex_colors[mesh.faces[index,:],:] = [0,0,0,255]
# mesh.show(smooth = False)

start_time = time.time()

### Initialising some constants and arrays

num_vertices = len(mesh.vertices)
num_faces = len(mesh.faces)

area = np.zeros(num_vertices)

### Find areas of connected faces

np.add.at(area, mesh.faces, mesh.area_faces[:,None])

## Function adds all as a vector, equivalent to area[mesh.faces] += mesh.area_faces
## but deals with repeated indices where the latter doesn't.

A = area / 3

A = sp.sparse.diags(A).tocsr() # required for big meshes

print(time.time() - start_time)
print('A Done')

### Calculate timestep as in the paper

t = (np.mean(mesh.edges_unique_length) ** 2)

t = t * 10 ** 0 ## some meshes may need slightly higher values

### Generate domain of gamma (basically just ones at the points to measure from, they act as heat 'sources')

deltas = np.zeros([len(mesh.vertices),1])

## Choice of index formulations, multiple points work

# index = [763, 453]

index = [6] # 763 good for large bunny

# tail = np.argmax(mesh.vertices[:,2])
# snout = np.argmin(mesh.vertices[:,2])
# foot = np.argmin(mesh.vertices[:,1])
# index = [tail, snout, foot]

# index = (np.random.randint(0, len(mesh.vertices), 3))

deltas[index] = 1


### Cotan Operator

## generate cotans
angles_cot = 1 / np.tan(mesh.face_angles)

## empty array
L_c = sp.sparse.dok_matrix((num_vertices, num_vertices))

## For each column (vertex on a face)
for j in range(3):

    ## Take the relevant list of cotans
    cotans = angles_cot[:, j]

    indexes = range(3)

    ## This provides the 'other' indexes, ie. 1,2 if j = 0 etc.
    indexes = np.delete(indexes, j)

    ## Take pairs of vertices
    edges = mesh.faces[:,[indexes[0],indexes[1]]]

    ## Find if there are any explicit repeats, to avoid the issue of vector sums not taking repeats
    ## into account (add.at doesn't work with sparse matrices unfortunately)
    uniques, counts = np.unique(edges, axis = 0, return_counts=True)

    multiples = (uniques[np.where(counts > 1)])

    ## This is generally empty, but it doesn't have to be, acts as a check when running
    print(multiples)

    ## If no multiples, just add the cotans to the appropriate index
    if multiples.shape[0] == 0:
        L_c[edges[:,0], edges[:,1]] += cotans * 0.5
        L_c[edges[:,1], edges[:,0]] += cotans * 0.5

    ## If there are, remove them and add again later (assumes only 1 repeat is possible)
    else:
        extras = np.zeros((multiples.shape[0], 3))

        L_c[edges[:,0], edges[:,1]] += cotans * 0.5
        L_c[edges[:,1], edges[:,0]] += cotans * 0.5

        for n, i in enumerate(multiples):

            locs = np.where(np.logical_and(edges[:,0] == i[0], edges[:,1] == i[1]))[0]
            repeats = locs[1:]

            extras[n, [0, 1]] = edges[repeats]
            extras[n, 2] = cotans[repeats]

        L_c[extras[:, 0], extras[:, 1]] += extras[:,2]
        L_c[extras[:, 1], extras[:, 0]] += extras[:,2]


## Set diagonals to negative of the sum of the rows
L_c.setdiag(-L_c.sum(axis=1))

## Change sparse type for later
L_c = sp.sparse.csr_matrix(L_c)

print(time.time() - start_time)
print('L_c Done')

### Solve for u

u = sp.sparse.linalg.spsolve((A - t*L_c), deltas)
u = np.atleast_2d(u).T

print(time.time() - start_time)
print('u Done')

### Calculate Grad u

## Find vectors of all edges, ensuring consistent direction
edges_1 = mesh.vertices[mesh.faces[:,2]] - mesh.vertices[mesh.faces[:,1]]
edges_2 = mesh.vertices[mesh.faces[:,0]] - mesh.vertices[mesh.faces[:,2]]
edges_3 = mesh.vertices[mesh.faces[:,1]] - mesh.vertices[mesh.faces[:,0]]

## Take cross product of face normal and multiply by correct u value
cross_1 = u[mesh.faces[:,0]] * np.cross(mesh.face_normals, edges_1)
cross_2 = u[mesh.faces[:,1]] * np.cross(mesh.face_normals, edges_2)
cross_3 = u[mesh.faces[:,2]] * np.cross(mesh.face_normals, edges_3)

## Calculate grad u as per the equation
grad_u = np.atleast_2d(1 / (2*mesh.area_faces)).T * (cross_1 + cross_2 + cross_3)

print(time.time() - start_time)
print('Grad u Done')

### Normalise Grad u to give X

X = - grad_u / np.atleast_2d(np.linalg.norm(grad_u, axis = 1)).T

print(time.time() - start_time)
print('X Done')

### Calculate Divergence of X

div_X = np.zeros(len(mesh.vertices))

## For each column (vertex on a face)
for j in range(3):

    ## Generate the 'other' indices again
    indexes = np.delete(np.array([0,1,2]), j)

    i1 = indexes[0]
    i2 = indexes[1]

    ## Generate appropriate geometric quantities
    e1 = mesh.vertices[mesh.faces[:, indexes[0]]] - mesh.vertices[mesh.faces[:, j]]
    e2 = mesh.vertices[mesh.faces[:, indexes[1]]] - mesh.vertices[mesh.faces[:, j]]
    cot1 = angles_cot [:, indexes[0]]
    cot2 = angles_cot [:, indexes[1]]

    ## Combine into a value to add onto the index
    face_val = 0.5 * (cot1 * np.sum(e2 * X, axis = 1) + cot2 * np.sum(e1 * X, axis = 1))

    ## Once again just a fancy vectorised sum that can cope with repeats in the indices
    ## equivalent to div_X[mesh.faces[:,j] += face_val
    np.add.at(div_X, mesh.faces[:, j], face_val)

print(time.time() - start_time)
print('Div X Done')

### Solve the poisson equation for phi

phi = sp.sparse.linalg.spsolve(L_c, div_X)

print(time.time() - start_time)
print('Phi Done')

## normalise phi for plotting
phi = (phi - np.min(phi)) / (np.max(phi) - np.min(phi))
# phi = (phi - np.min(phi))

## colourmap options (generally for when not plotting phi)

# color_range = np.array([[0, 0, 0, 255], [255, 255, 255, 255]])
# color_range = np.array([[200, 33, 40, 255], [32, 27, 80, 255]])
# color_range = np.array([[200, 33, 40, 255], [255, 255, 255, 255]])
color_range = np.array([[255, 255, 255, 255], [255, 0, 0, 255]])
# color_range = np.array([[255, 0, 0, 255], [255, 255, 255, 255]])

## in case plotting u is needed
# u = (u - np.min(u)) / (np.max(u) - np.min(u))

# mesh.visual.vertex_colors = trimesh.visual.color.linear_color_map(u, color_range)


## Colourmap etc
Inferno = plt.get_cmap('inferno_r')

colors = Inferno(phi) * 255

mesh.visual.vertex_colors = colors

## Colour the heat sources black for identification
for i in index:
    # neighbours = mesh.vertex_neighbors[i]
    # mesh.visual.vertex_colors[neighbours,:] = np.array([0,0, 0,255])
    mesh.visual.vertex_colors[i,:] = np.array([0,0, 0,255])

mesh.show(smooth = True)

## extra variable plotting code

# plot_var = np.sort(phi, axis = 0)
# # plot_var = phi
#
# plt.plot(np.arange(len(plot_var)), plot_var, 'x')
# # plt.hist(plot_var, bins = 10000)
# plt.show()


