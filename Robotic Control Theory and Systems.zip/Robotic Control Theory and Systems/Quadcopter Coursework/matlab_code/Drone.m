%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Drone class, feel free to add functionality as you see fit
%%%%  Author: Daniel Butters
%%%%  Date: 16/11/17
%%%%
%%%%  Edited by Daniel Mead 29/12/18
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

classdef Drone < handle
    properties (Constant)
        %width, length, height offset between centre and rotors
        body = [0.5 0.5 0.0];
        
        %time interval for simulation (seconds)
        time_interval = 0.02;
        
        % size of floating window that follows drone
        axis_size = 2.;
        
        %colours of each component of drone model
        colours = [[.8 .3 .1];[.2 .2 .5];[.8 .1 .3];[.9 .6 .8];[.9 .2 .4]];
                
        %Follows the drone within the figure
        %Don't use if you are simulating more than one drone!
        %Switch to false to see the overall world view
        drone_follow = true;
        
        %Optional additional parameters (not working fully, do not test
        %unless to prove the simulation still runs)
        
        wind_present = false;
        
        wind_turbulent = false;
        
        noise_present = false;
    end
    properties
        %axis to draw on
        axis
        
        %length of one side of the flight arena
        spaceDim
        
        %limits of flight arena
        spaceLimits
        
        %drone position
        pos
        
        %drone rotation matrix
        R
        
        %drone position derivative
        posdot
        
        %drone rotation matrix derivative
        Rdot
        
        %Simulation time
        time
        
        %parameter to start drone in random position
        pos_offset
        
        %number of drones
        num_drones
        
        
        %State variables for controller
        state_integral
        
        checkpoints
        
        checkpoints_num
        
        checkpoint_marker
        
        loop_num
        
        loop_time
        
        % Variable for displays as requested
        
        distance_travelled
        
        distance_from_ideal
        
        last_checkpoint
        
    end
    methods
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %INSTANTIATION OF CLASS
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        function obj = Drone(axis, spaceDim, num_drones)
            if nargin > 1
                obj.axis = axis;
                
                obj.spaceDim = spaceDim;
                
                obj.spaceLimits = [(-spaceDim/2)+10 (spaceDim/2)-10 (-spaceDim/2)+10 (spaceDim/2)-10 10 spaceDim-10];
                
                obj.pos = [0;0;0];
                
                obj.pos_offset = [0;0;0];
                
                obj.R = [1,0,0;0,1,0;0,0,1];
                
                obj.posdot = [0;0;0];
                
                obj.Rdot = [0,0,0;0,0,0;0,0,0];
                
                obj.time = 0;
                
                obj.num_drones = num_drones;
                
                obj.state_integral = zeros(6,1);
                
                obj.checkpoints = [0,0,10];
                
                obj.checkpoints_num = 1;
                
                obj.checkpoint_marker = [0, 0, 0, 0];
                
                obj.loop_num = 1;
                
                obj.loop_time = 0;
                
                obj.distance_travelled = 0;
                
                obj.distance_from_ideal = 0;
                
                obj.last_checkpoint = [0, 0, 0];
                
            else
                error('Drone not initialised correctly')
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %DRAWING OF DRONE TO FIGURE
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        function draw(obj)
            %how big should the moving window be
            cL = obj.axis_size;
            
            %set to false if you want to see world view
            if(obj.drone_follow)
                axis([obj.pos(1)-cL obj.pos(1)+cL obj.pos(2)-cL obj.pos(2)+cL obj.pos(3)-cL obj.pos(3)+cL]);
            end
            
            %create middle sphere
            [X Y Z] = sphere(8);
            %[X Y Z] = (obj.body(1)/5.).*[X Y Z];
            X = (obj.body(1)/5.).*X + obj.pos(1);
            Y = (obj.body(1)/5.).*Y + obj.pos(2);
            Z = (obj.body(1)/5.).*Z + obj.pos(3);
            s = surf(obj.axis,X,Y,Z);
            set(s,'edgecolor','none','facecolor',obj.colours(1,:));
            
            %create side spheres
            %front, right, back, left
            hOff = obj.body(3)/2;
            Lx = obj.body(1)/2;
            Ly = obj.body(2)/2;
            rotorsPosBody = [...
                0    Ly    0    -Ly;
                Lx    0    -Lx   0;
                hOff hOff hOff hOff];
            rotors_Inertial = zeros(3,4);
            for i = 1:4
                rotorPosBody = rotorsPosBody(:,i);
                rotorsPosInertial(:,i) = bodyToInertial(obj,rotorPosBody);
                [X Y Z] = sphere(8);
                X = (obj.body(1)/8.).*X + obj.pos(1) + rotorsPosInertial(1,i);
                Y = (obj.body(1)/8.).*Y + obj.pos(2) + rotorsPosInertial(2,i);
                Z = (obj.body(1)/8.).*Z + obj.pos(3) + rotorsPosInertial(3,i);
                s = surf(obj.axis,X,Y,Z);
                set(s,'edgecolor','none','facecolor',obj.colours(i+1,:));
            end
%             obj.axis.Title.String = ['Sim Time =
%             ',num2str(obj.time,'%f'),' seconds']; % Supplanted by the
%             text box
        end
        
        function vectorInertial = bodyToInertial(obj, vectorBody)
            vectorInertial = obj.R*vectorBody;
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %SIMULATION FUNCTIONS
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
               
        function obj = move(obj) %%% THIS FUNCTION SHOULD NOT BE USED
            
            %Code mostly adapted from Gibiansky
            %This function uses old values for a drone which is largely not
            %compatible with the current model, it should not be used.
            
            % Initial simulation state.
            
            t = obj.time;
            
            x = obj.pos;   
            theta = transpose(rotm2eul(obj.R, 'XYZ'));
            
            xdot = obj.posdot;
            thetadot = transpose(rotm2eul(obj.Rdot, 'XYZ'));

            dt = obj.time_interval;
            
            motor_weight = 142;
            ESC_weight = 29;
            rotor_weight = 37;

            m = 4.2; % For same wingspan: https://www.unmannedtechshop.co.uk/product/dys-d800-x4-professional-multi-rotor-package-for-aerial-photography-and-heavy-lift-pnf/
            g = 9.81;
            k = 0.1; % No idea about the value of this, will change through testing.
            kd = 0.25;
            inertia = 0.4^2 * (motor_weight + ESC_weight + rotor_weight);
            I = [inertia*2 0 0; 0 inertia*2 0 ; 0 0 4*inertia;];
            L = obj.body(1)/2;
            b = 0.1;

            i = input(t);

            omega = thetadot2omega(thetadot, theta);

            % Compute linear and angular accelerations.
            a = acceleration(i, theta, xdot, m, g, k, kd);
            
            omegadot = angular_acceleration(i, omega, I, L, b, k);
            omega = omega + dt * omegadot;
            thetadot = omega2thetadot(omega, theta);
            theta = theta + dt * thetadot;
            xdot = xdot + dt * a;
            x = x + dt * xdot;
            
            %Don't go underground, simulated 'crash'
            
            if x(3) < 0
                x(3) = 0;
                xdot(3) = 0;
                xdot(1) = xdot(1)/10;
                xdot(2) = xdot(2)/10;
            end
            
            rot_mat = eul2rotm(transpose(theta), 'XYZ');
            
            %update position and rotation matrix of drone
                        
            obj.pos = x;
            obj.R = rot_mat;
            obj.posdot = xdot;
            obj.Rdot = eul2rotm(transpose(thetadot), 'XYZ');
            
%             pause(0.1)
            
            function i = input(t)
                i = [150, 150, 150, 150]; %These values are complete guesses, they can be changed to observe differing behaviours.
            end
        
        end
        
        function obj = move_to_loc(obj)
            
            %%% Initialise the values, no noises is added at this time. 
            
            t = obj.time;
            
            x = obj.pos;   
            theta = transpose(rotm2eul(obj.R, 'XYZ'));
            
            xdot = obj.posdot;
            thetadot = transpose(rotm2eul(obj.Rdot, 'XYZ'));

            dt = obj.time_interval;
            limits = obj.spaceDim;
            
            x_desired = obj.checkpoints(1);
            y_desired = obj.checkpoints(2);
            z_desired = obj.checkpoints(3);
            
            %%% Move to next checkpoint if within a range of values. If
            %%% reaching the end of a loop, randomise location
            
            if all(abs(transpose(x) - [x_desired, y_desired, z_desired]) < 0.1) && all(xdot < 0.01) && all(thetadot(1:2) < 1*pi/180)
                obj.last_checkpoint = obj.checkpoints;
                obj.checkpoint_marker = [obj.checkpoint_marker; obj.time, x_desired, y_desired, z_desired];
                obj.checkpoints_num = obj.checkpoints_num + 1;
                obj.loop_time = 0;
                
                if obj.checkpoints_num == 2
                    obj.checkpoints = obj.checkpoints + [10, 0 ,0];
                elseif obj.checkpoints_num == 3
                        obj.checkpoints = obj.checkpoints + [0, 10 ,0];
                elseif obj.checkpoints_num == 4
                    obj.checkpoints = obj.checkpoints + [-10, 0 ,0];
                elseif obj.checkpoints_num == 5
                    obj.checkpoints = obj.checkpoints + [0, -10 ,0];
                elseif obj.checkpoints_num == 6
                    obj.checkpoints = [limits*(rand - 0.5), limits*(rand - 0.5), rand*limits*0.9 + limits/10];
                    obj.checkpoints_num = 1;
                    obj.loop_num = obj.loop_num + 1;
                end
                   
            end
            
            %%% May need to recalculate
            
            x_desired = obj.checkpoints(1);
            y_desired = obj.checkpoints(2);
            z_desired = obj.checkpoints(3);
            
            %%% Constant values, either physical sense or adapted from
            %%% Gilonis as his model is similar to mine.
            
            m = 0.5;
            g = 9.81;
            k = 3e-6; 
            kd = 0.25;

            I = diag([5e-3, 5e-3, 10e-3;]);
            L = obj.body(1)/2;
            b = 1e-7;
            noise = obj.noise_present;
            
            %%% Generate input for the controller function
            
            controller_params = struct('dt',dt,'I',I,'k',k,'L',L,'b',b,'m',m,'g',g,...
             'xdes',x_desired,'ydes',y_desired,'zdes',z_desired, 'x', x, 'xdot', xdot, 'orientation', theta, 'integral',...
             obj.state_integral, 'noise', noise);
            
            %%% Calculate rotor values from inputs, currently
            %%% unconstrained, values from real-life models were not found.
            %%% Ideally would look at similar drones to find maximum
            %%% performance and apply limits accordingly.
         
            [inputs,controller_params] = pid_controller(controller_params, thetadot);
            
            obj.state_integral = controller_params.integral;
            
            %%% Following is just kinematics, all required functions can be
            %%% found in the folder.
            
            omega = thetadot2omega(thetadot, theta);
            
            % Compute linear and angular accelerations.
            a = acceleration(inputs, theta, xdot, m, g, k, kd);
            
            
            % Generate wind if required, turbulent currently has random
            % vector which is undesirable, not turbulent must be specified.
            
            if(obj.wind_present)
                if (obj.wind_turbulent)
                    wind = [0.04*(rand - 0.5); 0.04*(rand - 0.5); 0.04*(rand - 0.5)];
                else
                    wind = [0.02; 0.02; 0]; % 1 m/s wind
                end
                a= a + wind;
            end
            
            omegadot = angular_acceleration(inputs, omega, I, L, b, k);
            omega = omega + dt * omegadot;
            thetadot = omega2thetadot(omega, theta);
            theta = theta + dt * thetadot;
            xdot = xdot + dt * a;
            x = x + dt * xdot;
           
            
            %%% Don't go underground, simulated 'crash' or 'landing'(!)
            
            if x(3) < 0
                x(3) = 0;
                xdot(3) = 0;
                xdot(1) = xdot(1)/10;
                xdot(2) = xdot(2)/10;
            end
            
            rot_mat = eul2rotm(transpose(theta), 'XYZ');
            
            obj.distance_travelled = obj.distance_travelled + norm(obj.pos - x);
            
            %update position and rotation matrix of drone
                        
            obj.pos = x;
            obj.R = rot_mat;
            obj.posdot = xdot;
            obj.Rdot = eul2rotm(transpose(thetadot), 'XYZ');
            
            % Calculate deviation from ideal path
            
            obj.distance_from_ideal = cross((obj.pos - transpose(obj.last_checkpoint)), (obj.pos - transpose(obj.checkpoints)));
            
            obj.distance_from_ideal = norm(obj.distance_from_ideal) / norm((transpose(obj.checkpoints) - transpose(obj.last_checkpoint)));
            
            
            %%% These can be uncommented if outputs are wished to be
            %%% displayed. This is left to the operators discretion. 
            
%             clc
%             Time_Elapsed = t
%             Travel_Distance = obj.distance_travelled
%             Loop_Number = obj.loop_num
%             Loop_Time = obj.loop_time;
%             Checkpoint_Number = obj.checkpoints_num
%             Checkpoint_Locations = obj.checkpoints;
            
            obj.loop_time = obj.loop_time + 1;
            
        end
        
        
        function update(obj)
            
            %update simulation time
            obj.time = obj.time + obj.time_interval;
            
            %change position and orientation of drone
            obj = move_to_loc(obj);
            
            %draw drone on figure
            draw(obj);
        end
    end
end