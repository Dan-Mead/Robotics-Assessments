function omegadot = angular_acceleration(inputs, omega, I, L, b, k)
    tau = [
        L * k * (inputs(1) - inputs(3))
        L * k * (inputs(2) - inputs(4))
        b * (inputs(1) - inputs(2) + inputs(3) - inputs(4))
        ];
    omegadot = inv(I) * (tau - cross(omega, I * omega));
end