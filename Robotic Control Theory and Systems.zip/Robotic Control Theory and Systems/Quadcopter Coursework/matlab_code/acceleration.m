function a = acceleration(inputs, angles, xdot, m, g, k, kd)
    gravity = [0; 0; -g];
    R = eul2rotm(transpose(angles), 'XYZ');
    T = [0; 0; k * sum(inputs)];
    T = R * T;
    Fd = -kd * xdot;
    a = gravity + (T + Fd) * 1 / m ;
end