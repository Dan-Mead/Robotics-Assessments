function [inputs,state] = pid_controller(state, thetadot)
    
    %%% Majority of this code was originally written by Gilonis, and has
    %%% been adapted, with a change in some parameters. 
    
    %Gain Parameters
    
    Kp_phi = 4;
    Kd_phi = 2;
    Ki_phi = 0;

    % Due to symmetry, X and Y gains can be identical.
    
    Kp_theta = Kp_phi;
    Kd_theta = Kd_phi;
    Ki_theta = Ki_phi;

    Kp_psi = 5;
    Kd_psi = 4;
    Ki_psi = 0.06;
    
    % No meaningful forces in x and y means no integral needed to cope with
    % steady-state.
    
    Kp_x = 2*pi/180;
    Kd_x = -3*pi/180;
    Ki_x = 0.0;

    Kp_y = Kp_x;
    Kd_y = Kd_x;
    Ki_y = Ki_x;

    Kp_z = 3e5;
    Kd_z = -2.2e5;
    Ki_z = 0.95e5;


    %%% Initalise and begin calculating errors on position
    
    inputs = zeros(4,1);
    
    x_des=state.xdes;
    y_des=state.ydes;
    z_des=state.zdes;
    
    x=state.x(1);
    y=state.x(2);
    z=state.x(3);
    
    % Generate noise from a gaussian with a 10cm stdv
    
    if(state.noise) 
       x = x + randn*0.1;
       y = y + randn*0.1;
       z = z + randn*0.1;
    end
    
    error_x=x_des-x;
    error_y=y-y_des;
    error_z=z_des-z;
    
    vels=state.xdot;
    xdot=vels(1);
    ydot=vels(2);
    zdot=vels(3);
    
    errordot_x=xdot;
    errordot_y=-ydot;
    errordot_z=zdot;
        
    int_x=state.integral(1);
    int_y=-state.integral(2);
    int_z=state.integral(3);
    int_phi=state.integral(4);
    int_theta=state.integral(5);
    int_psi=state.integral(6);
    
    %%% phi and theta control x and y motion, but the angles should be
    %%% limited so as to avoid too dramatic motion.
       
    phi_des= Kp_y*error_y + Kd_y*errordot_y + Ki_y*int_y;
    
    if phi_des>pi/6
        phi_des=pi/6;
    end
    if phi_des<-pi/6
        phi_des=-pi/6;
    end
    
    theta_des= Kp_x*error_x + Kd_x*errordot_x + Ki_x*int_x;
    
    if theta_des>pi/6
        theta_des=pi/6;
    end
    if theta_des<-pi/6
        theta_des=-pi/6;
    end
        
    % No reason for yaw to change
    
    psi_des=0.0;
    
    % Calculate errors on angles
    
    phi=state.orientation(1);
    theta=state.orientation(2);
    psi=state.orientation(3);
    
    % Generate noise from a gaussian with a 10 degree stdv
    
    if(state.noise) 
       phi = phi + 10*randn*pi/180;
       theta = theta + 10*randn*pi/180;
       psi = psi + 10*randn*pi/180;
    end
    
    phidot=thetadot(1);
    thetadot2=thetadot(2);
    psidot=thetadot(3);
    
    error_phi=phi_des-phi;
    error_theta=theta_des-theta;
    error_psi=psi_des-psi;

    e_phi= Kp_phi*-error_phi+Kd_phi*phidot+Ki_phi*int_phi;
    e_theta= Kp_theta*-error_theta+Kd_theta*thetadot2+Ki_theta*int_theta;
    e_psi= Kp_psi*-error_psi+Kd_psi*psidot+Ki_psi*int_psi;

    Ixx=state.I(1,1);
    Iyy=state.I(2,2);
    Izz=state.I(3,3);

    b=state.b;
    k=state.k;
    L=state.L;
    m=state.m;
    g=state.g;
    dt=state.dt;
    
    errors=[error_x;error_y;error_z;error_phi;error_theta;error_psi];


    % Thrust equation given by error in z (vertical motion is inherently
    % controlled by thrust)
    
    thrust = Kp_z*error_z + Kd_z*errordot_z + Ki_z*int_z;
    
    % Prevent negative thrust, as we have gravity
    
    if thrust<0
        thrust=0;
    end
    

    % Calaculate propellor outputs. Equations taken from both Giabansky and
    % Gilonis
    
    inputs(1)= thrust/4 + (-2*b*e_phi*Ixx - k*L*e_psi*Izz)/(4*b*L*k);
    inputs(2)= thrust/4 + (-2*b*e_theta*Iyy + k*L*e_psi*Izz)/(4*b*L*k);
    inputs(3)= thrust/4 + (2*b*e_phi*Ixx - k*L*e_psi*Izz)/(4*b*L*k);
    inputs(4)= thrust/4 + (2*b*e_theta*Iyy + k*L*e_psi*Izz)/(4*b*L*k);

    % Update Integral for next time

    state.integral = state.integral + dt*errors;
   
end