Run quadcopter_script.m and the simulation should work. Most functionality occurs in the 'Drone.m' though parameter tuning in the 'pid_controller.m' can also be done.

Running quadcopter_script.m will inialise the drone to loop 10 times starting with a set square as given in the brief, then moving to a random point within the requested
100x100 cube and drawing out a new square. After 10 loops have elapsed, the system should stop automatically, though it will not close. The drone is fully automated and 
managed by a PID controller and will output various telemetries including the total distance travelled and the deviation from ideal path. Wind and noise are, by default, 
set to false.