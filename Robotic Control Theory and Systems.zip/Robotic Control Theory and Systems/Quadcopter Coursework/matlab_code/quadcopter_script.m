%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  Visualisation code for quadcopter 
%%%%  Author: Daniel Butters
%%%%  Date: 16/11/17
%%%%
%%%%  Edited by Daniel Mead 29/12/18
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
close all;

%Define total width, length and height of flight arena (metres)
spaceDim = 100;
spaceLimits = [-spaceDim/2 spaceDim/2 -spaceDim/2 spaceDim/2 0 spaceDim];


draw_ground = false; %can be true but generally unecessary
if(draw_ground)
    ground_img = imread('ground.png');
end


%figure to display drone simulation
% f1 = figure; % not fullscreen
f1 = figure('units','normalized','outerposition',[0 0 1 1]); %fullscreen
ax1 = gca;
axis(spaceLimits)
grid ON
grid MINOR
axis('manual')
caxis(ax1, [0 spaceDim]);
hold(ax1,'on')
axis vis3d

num_drones = 1;

%instantiate a drone object, input the axis and arena limits
drones = [];
for i = 1:num_drones
    drones = [drones Drone(ax1, spaceDim, num_drones)];
end

% %%% Create arrays for recording telemetries
% 
% x = [0];
% y = [0];
% z = [0];

% %%% Start Video Recorder
% 
% pause(0.1)
% 
% % create the video writer with 1 fps
% writerObj = VideoWriter('demovideo.avi');
% writerObj.FrameRate = 25;
% % set the seconds per image
% 
% pause(0.01)
% 
% % open the video writer
% open(writerObj);
% 
% pause(0.01)

%%% Initial Conditions

num_loops = 10;
dim = [0.1 0.4 0.16 0.26]; %Infobox dimensions

while(drones(1).loop_num < (num_loops+1))
    cla(ax1);
    
    %update and draw drones
    for i = 1:num_drones
        update(drones(i));
    end
    
    time = drones(1).time;
    
    %optionally draw the ground image
    if(draw_ground)
        imagesc([-spaceDim,spaceDim],[-spaceDim,spaceDim],ground_img);
    end
        
    %apply fancy lighting (optional)
    camlight
    
    %%% Create strings to annotate plot with
    
    Time_Elapsed = time;
    Travel_Distance = drones(1).distance_travelled;
    Loop_Number = drones(1).loop_num;
    Checkpoint_Number = drones(1).checkpoints_num;
    Checkpoint_Locations = drones(1).checkpoints;
    Drone_pos = drones(1).pos;
    Deviation = drones(1).distance_from_ideal;
    
    time_string = sprintf('Time: %.2f s', Time_Elapsed);
    dist_string = sprintf('Distance Travelled: %.2f m', Travel_Distance);
    loop_string = sprintf('Loop: %d Checkpoint: %d', [Loop_Number, Checkpoint_Number]);
    checkpoint_string = sprintf('Checkpoint Location: %.2f %.2f %.2f', [Checkpoint_Locations(1), Checkpoint_Locations(2), Checkpoint_Locations(3)]);
    position_string = sprintf('Quadcopter Location: %.2f %.2f %.2f', [Drone_pos(1), Drone_pos(2), Drone_pos(3)]);
    deviation_string = sprintf('Deviation from ideal path: %.2f', Deviation);
    data = {time_string,'', dist_string,'', loop_string,'', checkpoint_string, '', position_string, '', deviation_string};
    
    delete(findall(gcf,'type','annotation'))
    
    %%% Annotate Plot
    
    annotation('textbox',dim, 'String',data, 'FitBoxToText','on', 'BackgroundColor', [0.9,0.9,0.9], 'FitHeightToText', 'on')
    
    %%% Update figure
    drawnow
    
    pause(0.01)
    
%     %%% Code for recording frames for videos and trajectories (generally
%     %%% run mutually exclusively)
%     frame_time_seperation = 0.04
%     if mod(round(drones(1).time,3), frame_time_seperation) == 0
%         writeVideo(writerObj, getframe(gcf))
%     end
    
%     x = [x, drones(1).pos(1)];
%     y = [y, drones(1).pos(2)];
%     z = [z, drones(1).pos(3)];
    

    %%% If code is stuck or takes too long, stop simulation.
    
    if drones(1).loop_time > 30/drones(1).time_interval
        drones(1).checkpoint_marker = [drones(1).checkpoint_marker; drones(1).time, drones(1).checkpoints(1),...
            drones(1).checkpoints(2), drones(1).checkpoints(3)];
        
        speeds = drones(1).posdot;
        final_angles = rotm2eul(drones(1).Rdot, 'XYZ');
        break
    end
    if time > 1000
        break
    
    end
end

% close(writerObj);

done = 'true'

%%% Plotting code for trajectories

% time = 0:drones(1).time_interval:drones(1).time_interval*length(z) - drones(1).time_interval;

% markers_t = drones(1).checkpoint_marker(:,1);
% markers_x = drones(1).checkpoint_marker(:,2);
% markers_y = drones(1).checkpoint_marker(:,3);
% markers_z = drones(1).checkpoint_marker(:,4);
% f2 = figure;
% hold on
% title('Trajectory of Quadcopter over time')
% xlabel('Time (s)') 
% ylabel('Location (m)') 
% plot(time,x, 'b', 'DisplayName','X Co-ordinate')
% plot(time,y, 'r', 'DisplayName','Y Co-ordinate')
% plot(time,z, 'g', 'DisplayName','Z Co-ordinate')
% scatter(markers_t,markers_x, 'bx', 'DisplayName','X Checkpoint')
% scatter(markers_t,markers_y, 'rx', 'DisplayName','Y Checkpoint')
% scatter(markers_t,markers_z, 'gx', 'DisplayName','Z Checkpoint')
% legend([],'Location','southwest')
% hold off
% saveas(f2,['Telemetry.jpg'])