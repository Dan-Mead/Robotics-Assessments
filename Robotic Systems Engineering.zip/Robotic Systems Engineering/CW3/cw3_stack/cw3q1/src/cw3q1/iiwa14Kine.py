#!/usr/bin/env python

import rospy
from math import pi
import numpy as np
import tf2_ros
from sensor_msgs.msg import JointState
from geometry_msgs.msg import TransformStamped, Quaternion
import itertools


class iiwa14_kinematic(object):

    def __init__(self):

        self.X_alpha = [pi / 2, pi / 2, pi / 2, pi / 2, pi / 2, pi / 2, 0.0]
        self.Y_alpha = [pi, pi, 0, pi, 0, pi, 0]
        self.current_joint_position = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

        self.joint_limit_min = [-170 * pi / 180, -120 * pi / 180, -170 * pi / 180, -120 * pi / 180, -170 * pi / 180,
                                -120 * pi / 180, -175 * pi / 180]
        self.joint_limit_max = [170 * pi / 180, 120 * pi / 180, 170 * pi / 180, 120 * pi / 180, 170 * pi / 180,
                                120 * pi / 180, 175 * pi / 180]

        ##The translation between each joint for manual forward kinematic (not using the DH convention).
        self.translation_vec = np.array([[0, 0, 0.2025],
                                         [0, 0.2045, 0],
                                         [0, 0, 0.2155],
                                         [0, 0.1845, 0],
                                         [0, 0, 0.2155],
                                         [0, 0.081, 0],
                                         [0, 0, 0.045]])

        ##The centre of mass of each link with respect to the preceding joint.
        self.link_cm = np.array([[0, -0.03, 0.12],
                                 [0.0003, 0.059, 0.042],
                                 [0, 0.03, 0.13],
                                 [0, 0.067, 0.034],
                                 [0.0001, 0.021, 0.076],
                                 [0, 0.0006, 0.0004],
                                 [0, 0, 0.02]])

        ##The mass of each link.
        self.mass = [4, 4, 3, 2.7, 1.7, 1.8, 0.3]

        ##Moment on inertia of each link, defined at the centre of mass.
        ##Each row is (Ixx, Iyy, Izz) and Ixy = Ixz = Iyz = 0.
        self.Ixyz = np.array([[0.1, 0.09, 0.02],
                              [0.05, 0.018, 0.044],
                              [0.08, 0.075, 0.01],
                              [0.03, 0.01, 0.029],
                              [0.02, 0.018, 0.005],
                              [0.005, 0.0036, 0.0047],
                              [0.001, 0.001, 0.001]])

        ##gravity
        self.g = 9.8

        self.joint_state_sub = rospy.Subscriber('/joint_states', JointState, self.joint_state_callback,
                                                queue_size=5)

        self.pose_broadcaster = tf2_ros.TransformBroadcaster()

    def rotmat2q(self, T):
        q = Quaternion()

        angle = np.arccos((T[0, 0] + T[1, 1] + T[2, 2] - 1) / 2)

        xr = T[2, 1] - T[1, 2]
        yr = T[0, 2] - T[2, 0]
        zr = T[1, 0] - T[0, 1]

        if (xr == 0) and (yr == 0) and (zr == 0):
            q.w = 1.0
            q.x = 0.0
            q.y = 0.0
            q.z = 0.0
        else:

            x = xr / np.sqrt(np.power(xr, 2) + np.power(yr, 2) + np.power(zr, 2))
            y = yr / np.sqrt(np.power(xr, 2) + np.power(yr, 2) + np.power(zr, 2))
            z = zr / np.sqrt(np.power(xr, 2) + np.power(yr, 2) + np.power(zr, 2))
            q.w = np.cos(angle / 2)
            q.x = x * np.sin(angle / 2)
            q.y = y * np.sin(angle / 2)
            q.z = z * np.sin(angle / 2)
        return q

    def joint_state_callback(self, msg):
        for i in range(0, 7):
            self.current_joint_position[i] = msg.position[i]

        current_pose = self.forward_kine(self.current_joint_position, 7)
        self.broadcast_pose(current_pose)

    def dh_matrix_standard(self, a, alpha, d, theta):
        A = np.zeros((4, 4))

        A[0, 0] = np.cos(theta)
        A[0, 1] = -np.sin(theta) * np.cos(alpha)
        A[0, 2] = np.sin(theta) * np.sin(alpha)
        A[0, 3] = a * np.cos(theta)

        A[1, 0] = np.sin(theta)
        A[1, 1] = np.cos(theta) * np.cos(alpha)
        A[1, 2] = -np.cos(theta) * np.sin(alpha)
        A[1, 3] = a * np.sin(theta)

        A[2, 1] = np.sin(alpha)
        A[2, 2] = np.cos(alpha)
        A[2, 3] = d

        A[3, 3] = 1.0

        return A

    def broadcast_pose(self, pose):

        transform = TransformStamped()

        transform.header.stamp = rospy.Time.now()
        transform.header.frame_id = 'iiwa_link_0'
        transform.child_frame_id = 'iiwa_ee'

        transform.transform.translation.x = pose[0, 3]
        transform.transform.translation.y = pose[1, 3]
        transform.transform.translation.z = pose[2, 3]
        transform.transform.rotation = self.rotmat2q(pose)

        self.pose_broadcaster.sendTransform(transform)

    ##Transformation functions for forward kinematic.
    def T_translation(self, t):
        T = np.identity(4)
        for i in range(0, 3):
            T[i, 3] = t[i]
        return T

    ##Transformation functions for forward kinematic.
    def T_rotationZ(self, theta):
        T = np.identity(4)
        T[0, 0] = np.cos(theta)
        T[0, 1] = -np.sin(theta)
        T[1, 0] = np.sin(theta)
        T[1, 1] = np.cos(theta)
        return T

    ##Transformation functions for forward kinematic.
    def T_rotationX(self, theta):
        T = np.identity(4)
        T[1, 1] = np.cos(theta)
        T[1, 2] = -np.sin(theta)
        T[2, 1] = np.sin(theta)
        T[2, 2] = np.cos(theta)
        return T


    ##Transformation functions for forward kinematic.
    def T_rotationY(self, theta):
        T = np.identity(4)
        T[0, 0] = np.cos(theta)
        T[0, 2] = np.sin(theta)
        T[2, 0] = -np.sin(theta)
        T[2, 2] = np.cos(theta)
        return T


    def forward_kine(self, joint, frame):
        T = np.identity(4)

        ##Add offset from the iiwa platform.
        T[2, 3] = 0.1575

        ##Manual forward kine for dynamics purpose. This chain of transformation works exactly the same as forward kinematic.
        for i in range(0, frame):
            T = T.dot(self.T_rotationZ(joint[i]))
            T = T.dot(self.T_translation(self.translation_vec[i, :]))
            T = T.dot(self.T_rotationX(self.X_alpha[i]))
            T = T.dot(self.T_rotationY(self.Y_alpha[i]))

        return T


    def forward_kine_cm(self, joint, frame):

        """Calculates the centre of mass of the requested frame."""

        frame = frame - 1 #needed to maintain offsets

        T = self.forward_kine(joint, frame)

        T = T.dot(self.T_rotationZ(joint[frame]))
        T = T.dot(self.T_translation(self.link_cm[frame, :]))
        T = T.dot(self.T_rotationX(self.X_alpha[frame]))
        T = T.dot(self.T_rotationY(self.Y_alpha[frame]))

        return T

    def get_jacobian(self, joint):

        """ Jacobian calculation same as in CW2"""

        n = len(self.current_joint_position)

        T = np.identity(4)

        T[2, 3] = 0.1575

        Zs = [T[0:3, 2]]
        Ps = [T[0:3, 3]]

        ##Manual forward kine for dynamics purpose. This chain of transformation works exactly the same as forward kinematic.
        for i in range(n):
            T = T.dot(self.T_rotationZ(joint[i]))
            T = T.dot(self.T_translation(self.translation_vec[i, :]))
            T = T.dot(self.T_rotationX(self.X_alpha[i]))
            T = T.dot(self.T_rotationY(self.Y_alpha[i]))

            Zs.append(T[0:3, 2])
            Ps.append(T[0:3, 3])

        J = np.zeros([6, n])
        Pe = Ps[-1]

        for i in range(n):

            Zi = Zs[i]
            Oi = Ps[i]

            Jp = np.cross(Zi, (Pe - Oi))
            Jo = Zi
            for k in range(3):
                J[k, i] = Jp[k]
                J[k + 3, i] = Jo[k]

        return J

    def get_jacobian_cm(self, joint, frame):

        """Jacobian with reference to the centre of mass of the specified frame"""

        n = len(self.current_joint_position)

        T = np.identity(4)

        T[2, 3] = 0.1575

        Zs = [T[0:3, 2]]
        Ps = [T[0:3, 3]]

        J = np.zeros([6, n])

        P_cm = self.forward_kine_cm(joint, frame)[0:3,3]

        ##Manual forward kine for dynamics purpose. This chain of transformation works exactly the same as forward kinematic.
        for i in range(n):

            T = T.dot(self.T_rotationZ(joint[i]))
            T = T.dot(self.T_translation(self.translation_vec[i, :]))
            T = T.dot(self.T_rotationX(self.X_alpha[i]))
            T = T.dot(self.T_rotationY(self.Y_alpha[i]))

            Zs.append(T[0:3, 2])
            Ps.append(T[0:3, 3])

        for i in range(n):

            Z = Zs[i]
            P = Ps[i]

            Jp = np.cross(Z, (P_cm - P))
            Jo = Z
            for k in range(3):
                J[k, i] = Jp[k]
                J[k + 3, i] = Jo[k]

        return J

    def rotmat2pr(self, T):

        """Brief function to convert to poses for Jacobian calculation"""

        x = np.zeros([6])
        x[0:3] = T[0:3,-1]

        theta = np.arccos((T[0,0] + T[1,1] + T[2,2] - 1)/2)

        if theta == 0:
            x[3:6] = 0
        else:
            x[3] = (1/(2*np.sin(theta)))*(T[2,1] - T[1,2])
            x[4] = (1/(2*np.sin(theta)))*(T[0,2] - T[2,0])
            x[5] = (1/(2*np.sin(theta)))*(T[1,0] - T[0,1])

        return x

    def inverse_kine_ite(self, desired_pose, current_joint):

        """Find a solution to a pose close to a given current joint via an iterative method. All equations are taken from
            lecture slides."""

        max = np.array(self.joint_limit_max)
        min = np.array(self.joint_limit_min)

        k = 0

        alpha = 0.001  # Margin of error for translational component
        beta = 0.5 * np.pi / 180  # Margin of error for rotational component
        gamma = 0.01  # Multiplier for the gradient descent.
        q_k = current_joint
        p_end = self.rotmat2pr(desired_pose)
        p_q = self.rotmat2pr(self.forward_kine(q_k, len(q_k)))

        ### Loop while aim and calculated values are sufficiently different.

        while any((abs(diff) > alpha) for diff in (p_end - p_q)[0:3]) or any(
                (abs(diff) > beta) for diff in (p_end - p_q)[3:6]):
            T_q = self.forward_kine(q_k, len(q_k))
            J_q = self.get_jacobian(q_k)
            p_q = self.rotmat2pr(T_q)
            q_k_old = q_k

            A = np.transpose(J_q)
            B = np.linalg.inv(np.matmul(J_q, A) + gamma**2 * np.eye(J_q.shape[0]))
            C = (p_end - p_q)
            # q_k = q_k + gamma * np.matmul(np.linalg.pinv(J_q), (p_end - p_q))  ### pinv or transpose can be used, with differing 'gammas'
            q_k = q_k + np.matmul(np.matmul(A, B), C)

            k += 1

            if all(abs(q_k_old - q_k)[0:3]) < alpha and all(abs(q_k_old - q_k)[3:6]) < beta:
                # If there is no improvement between iterations, stop calculating. Ideally the function would then be reinitialised fromm
                # a new point as this can only really happen if it is in a local minima which is not the solution.
                break
            if k >= 1000:
                # After a certain point, just stop.
                break

        for n in range(q_k.shape[0]):
            while q_k[n] < min[n]:
                q_k[n] = q_k[n] + 2*np.pi
            while q_k[n] > max[n]:
                q_k[n] = q_k[n] - 2*np.pi
        return q_k


    def inverse_kine_closed_form(self, desired_pose):

        """Closed Form Inverse Kinematics function, solutions have an appendix index to determine viability, -1 is not a valid
        solution, 0 is a solution that is outside joint limits or a singularity, 1 is a valid solution. Detailed literature is found
        in the report."""

        wrist_length = 0.045 + 0.081 # values taken from forward kinematics

        wrist_diff = np.transpose(np.array([0, 0, -wrist_length, 1]))
        Pw = np.matmul(desired_pose, wrist_diff)[0:3]

        Ps = self.forward_kine(np.zeros(7),1)[0:3,-1]

        Psw = Pw - Ps

        l_bs = self.forward_kine(np.zeros(7), 1)[2, -1]
        l_se = self.forward_kine(np.zeros(7), 3)[2, -1] - l_bs
        l_ew = self.forward_kine(np.zeros(7), 5)[2, -1] - (l_se + l_bs)

        l_sw = np.linalg.norm(Psw)

        v_th3 = 0

        v_th1 = np.arctan2(Psw[1], Psw[0])

        K1 = (l_se**2 + l_sw**2 - l_ew**2)/(2*l_se*l_sw)
        if abs(K1) > 1:
            K1 = K1 / abs(K1)

        extra_angle = np.arccos(K1)

        K2 = (l_sw**2 - l_se**2 - l_ew**2)/(2*l_se*l_ew)

        if abs(K2) > 1:
            K2 = K2 / abs(K2)

        for signs in itertools.product([-1, 1], repeat=2):
            v_th4 = signs[0] * np.arccos(K2) * signs[1]
            v_th2 = np.arctan2(np.sqrt(Psw[0]**2 + Psw[1]**2), Psw[2]) + signs[0] * extra_angle * signs[1]
            if np.allclose(self.forward_kine(np.array([v_th1, v_th2, v_th3, v_th4, 0, 0, 0]), 5)[0:3, -1], Pw):
                break

        vTe = self.forward_kine(np.array([v_th1, v_th2, v_th3, v_th4, 0, 0, 0]), 3)

        vPe = vTe[0:3,-1]

        vPse = vPe - Ps

        Pc = np.dot(vPse, Psw)

        Pc = (Pc / l_sw) * (Psw / l_sw)

        Rc = vPse - Pc

        R = np.linalg.norm(Rc)

        phi = 0 # other values not working right now

        Usw = Psw / np.linalg.norm(Psw)

        Msw = np.zeros([3,3])

        Msw[0,1] = -Usw[2]
        Msw[1,0] = Usw[2]
        Msw[0,2] = Usw[1]
        Msw[2,0] = -Usw[1]
        Msw[1,2] = -Usw[0]
        Msw[2,1] = Usw[0]

        vR03 = vTe[0:3,0:3]

        Rphi = np.eye(3) + np.sin(phi) * Msw + (1 - np.cos(phi)) * np.matmul(Msw, Msw)

        R03 = np.matmul(Rphi, vR03)

        solutions = np.empty([1,8])

        for signs in itertools.product([-1, 1], repeat=5):

            th1 = np.arctan2(signs[0] * R03[1,1], signs[0] * R03[0,1])

            th2 = signs[0] * np.arccos(R03[2,1]) * signs[3]

            th3 = np.arctan2(signs[0] * -R03[2, 2], signs[0] * -R03[2, 0])

            th4 = signs[1] * np.arccos((l_sw**2 - l_se**2 - l_ew**2)/(2 * l_se * l_ew))

            T04 = self.forward_kine(np.array([th1, th2, th3, th4, 0, 0, 0]), 4)

            T47 = np.matmul(np.linalg.inv(T04), desired_pose)

            R47 = T47[0:3,0:3]

            th5 = np.arctan2(signs[2] * R47[1,2], signs[2] * R47[0,2])

            th6 = signs[2] * np.arccos(R47[2,2]) * signs[4]

            th7 = np.arctan2(signs[2] * R47[2, 1], signs[2] * -R47[2,0])

            new_joints = np.array([th1, th2, th3, th4, th5, th6, th7, 1])

            diff = desired_pose[0:3,-1] - self.forward_kine(new_joints,7)[0:3,-1]

            if np.allclose(diff, np.zeros(3)) == True:
                if np.all((self.joint_limit_max - new_joints[0:-1]) > 0) and np.all((new_joints[0:-1] - self.joint_limit_min) > 0):
                    if self.check_singularity(new_joints[0:-1]) == 1:
                        new_joints[-1] = 0
                    solutions = np.vstack((solutions, new_joints))
                    # break
                else:
                    new_joints[-1] = 0
                    solutions = np.vstack((solutions, new_joints))
            else:
                new_joints[-1] = -1
                solutions = np.vstack((solutions, new_joints))

        return solutions[1:,:]

    def check_singularity(self, current_joint):

        """ Check if a joint configuration represents a singularity. Used the determinant method rather than ranks."""

        J = self.get_jacobian(current_joint)

        if J.shape[0] == J.shape[1]:
            J_test = J
        else:
            JT = np.transpose(J)
            J_test = np.matmul(JT,J)

        det = np.linalg.det(J_test)

        if det == 0:
            return True
        else:
            return False

    def getB(self, joint):

        """Calculates dynamic component B, outputs a 7x7 matrix"""

        num_frames = len(joint)

        Ks = np.zeros([num_frames, 7,7])

        for j in range(num_frames):

            jacobi = self.get_jacobian_cm(joint,j)

            Jp = jacobi[0:3,:]
            Jo = jacobi[3:6,:]

            A = self.mass[j] * np.matmul(np.transpose(Jp), Jp)

            I = np.eye(3)

            I = I * self.Ixyz[j] * 4
            # I[0,0] = 0

            R = self.forward_kine(joint, j)[0:3,0:3]

            J = np.matmul(R, np.matmul(I, np.transpose(R)))

            B = np.matmul(J, Jo)

            C = np.matmul(np.transpose(Jo),B)

            Ks[j] = A + C

        B = np.sum(Ks, axis = 0)

        return B

    def differential(self, joint, q1):

        e = 1e-6

        joint1 = np.copy(joint)
        joint1[q1] = joint1[q1] + e

        diff = (self.getB(joint1) - self.getB(joint)) / e

        return diff

    def getC(self, joint, vel):

        """ Calculates the dynamic component C, output is 7x7"""

        num_frames = len(joint)

        C = np.zeros([num_frames, num_frames])

        diffmat = np.zeros([num_frames, num_frames, num_frames])

        for i in range(num_frames):
            diffmat[i,:,:] = self.differential(joint,i)

        for i in range(num_frames):
            for j in range(num_frames):
                Hs = np.zeros(7)
                for k in range(num_frames):
                    Hs[k] = diffmat[k,i,j] - 0.5 * diffmat[i, j,k]
                    Hs[k] = Hs[k] * vel[k]
                C[i, j] = np.sum(Hs)

        return C

    def getG(self, joint):

        """Calculates the dynamic component G, output is 7x1"""

        num_frames = len(joint)
        G = np.zeros(num_frames)
        g0 = np.array([0.0,0.0,-self.g])
        for i in range(num_frames):

            m = self.mass[i]
            J = self.get_jacobian_cm(joint, i)[0:3,:]
            G -= (m * np.matmul(g0, J))

        G = np.atleast_2d(G)
        G = np.transpose(G)

        return G

    def q2rotmat(self, q):

        """Function required for making use of quarternions in Q4c"""

        e0 = q[0] #q.w
        e1 = q[1] #q.x
        e2 = q[2] #q.y
        e3 = q[3] #q.z

        R = np.eye(3)

        R[0,0] = 1 - 2*(e2*e2 + e3*e3)
        R[0,1] = 2*(e1*e2 - e0*e3)
        R[0,2] = 2*(e1*e3 + e0*e2)
        R[1,0] = 2*(e1*e2 + e0*e3)
        R[1,1] = 1 - 2*(e1*e1 + e3*e3)
        R[1,2] = 2*(e2*e3 - e0*e1)
        R[2,0] = 2*(e1*e3 - e0*e2)
        R[2,1] = 2*(e2*e3 + e0*e1)
        R[2,2] = 1 - 2*(e1*e1 + e2*e2)

        R[np.abs(R) < 1e-15] = 0

        return R
