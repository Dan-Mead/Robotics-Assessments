#!/usr/bin/env python

from __future__ import division
import rospy
import rospkg
import rosbag
import sys
import numpy as np
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
from cw3q1.iiwa14Kine import iiwa14_kinematic
from kdl_kine.kdl_kine_solver import iiwa14KDL

iiwa = iiwa14_kinematic()
KDL = iiwa14KDL()

def callback(msg):

    """Callback function which calculated B, C, and G, and appends them (with time) to a arrays. Stops after a set time."""

    pos = msg.position
    vel = msg.velocity
    tau = msg.effort


    KDLB = kdl_to_mat(KDL.getB(pos))
    KDLC = kdl_to_array(KDL.getC(pos, vel))
    KDLG = kdl_to_array(KDL.getG(pos))

    tau = np.atleast_2d(tau)

    KDLG = np.atleast_2d(KDLG)
    KDLC = np.atleast_2d(KDLC)

    ### Rearranging the Dynamic Equation

    KDLaccel.append(np.matmul(np.linalg.inv(KDLB), (np.transpose(tau) - np.transpose(KDLG) - np.transpose(KDLC))))

    time.append(rospy.get_time() - start_publish - start_time)

    if rospy.get_time() > start_time + start_publish + 31: # time until stop spinning
        rospy.signal_shutdown('Test elapsed')

def kdl_to_mat(m):
    mat = np.array(np.zeros((m.rows(), m.columns())))
    for i in range(m.rows()):
        for j in range(m.columns()):
            mat[i,j] = m[i,j]
    return mat

def kdl_to_array(a):
    array = []
    for i in a:
        array.append(i)
    return array

def ground_truth():

    """Calculation of ground truth acceleration for comparison with calculated values. Uses a quintic polynomial."""

    rospack = rospkg.RosPack()

    path = rospack.get_path('cw3_launch')
    bag = rosbag.Bag(path + '/bags/cw3bag1.bag')

    checkpoints = np.zeros(len(iiwa.current_joint_position))
    velocities = np.zeros(len(checkpoints))
    accelerations = np.zeros(len(checkpoints))

    for topic, msg, t in bag.read_messages(topics=['/iiwa/EffortJointInterface_trajectory_controller/command']):
        points = msg.points

    bag.close()

    for i in range(len(points)):
        checkpoints = np.vstack((checkpoints, points[i].positions))
        velocities = np.vstack((velocities, points[i].velocities))
        accelerations = np.vstack((accelerations, points[i].accelerations))


    num_checkpoints = checkpoints.shape[0]
    checkpoint_dt = 10
    dt = 1

    ### Calculation as given in the report, via a constrained polynomial split between checkpoints.

    joint_locs = np.zeros([int(checkpoint_dt / dt * (num_checkpoints - 1) + 1),7])
    joint_vels = np.zeros([int(checkpoint_dt / dt * (num_checkpoints - 1) + 1),7])
    joint_accels = np.zeros([int(checkpoint_dt / dt * (num_checkpoints - 1) + 1),7])

    joint_locs[0,:] = checkpoints[0]
    joint_vels[0,:] = velocities[0]
    joint_accels[0,:] = accelerations[0]


    for n in range(num_checkpoints - 1):

        ts = n * checkpoint_dt
        tf = ts + checkpoint_dt

        A = np.array([[1, ts, ts ** 2, ts ** 3, ts ** 4, ts ** 5],
                      [0, 1, 2 * ts, 3 * ts ** 2, 4 * ts ** 3, 5 * ts ** 4],
                      [0, 0, 2, 6 * ts ** 1, 12 * ts ** 2, 20 * ts ** 3],
                      [1, tf, tf ** 2, tf ** 3, tf ** 4, tf ** 5],
                      [0, 1, 2 * tf, 3 * tf ** 2, 4 * tf ** 3, 5 * tf ** 4],
                      [0, 0, 2, 6 * tf ** 1, 12 * tf ** 2, 20 * tf ** 3]])
        B = np.array([checkpoints[n], velocities[n], accelerations[n], checkpoints[n + 1], velocities[n + 1],  accelerations[n + 1]])
        X = np.linalg.solve(A, B) ### God bless numpy.

        a0 = X[0, :]
        a1 = X[1, :]
        a2 = X[2, :]
        a3 = X[3, :]
        a4 = X[4, :]
        a5 = X[5, :]


        for t in np.linspace(ts + dt, tf, int(checkpoint_dt/dt)):
            i = int(t)
            joint_locs[i] = a0 + a1*t + a2*t**2 + a3*t**3 + a4*t**4 + a5*t**5
            joint_vels[i] = a1 + 2*a2*t + 3*a3*t**2 + 4*a4*t**3 + 5*a5*t**4
            joint_accels[i] = 2*a2 + 6*a3*t**1 + 12*a4*t**2 + 20*a5*t**3

    return joint_locs, joint_vels, joint_accels

def plot_versus(GT_accel, KDLaccel, accel, time):

    """Plotting of calculated values vs. Ground Truth, is not run by default. Output graph is provided in the report."""

    import matplotlib.pyplot as plt

    ts = np.arange(0, 31)
    ys = GT_accel[:, 1]


    KDLaccel = np.squeeze(np.atleast_2d(KDLaccel))

    ys2 = KDLaccel[:, 1]

    plt.plot(ts, ys, label='Ground Truth')
    plt.plot(time, ys2, label='KDL')
    plt.xlim(0, 30)
    plt.xlabel('Time')
    plt.ylabel('Joint 2 acceleration')
    plt.legend()
    plt.show()

### Initialise

rospy.init_node('cwq2a_receiver')

### Calculate empty arrays

GTloc, GT_vel, GT_accel = ground_truth()

start_time = rospy.get_time()
start_publish = 5
KDLaccel = []
accel = []
time = []

### Begin Subscriber

sub = rospy.Subscriber('/iiwa/joint_states', JointState, callback)

rospy.spin()

### Data management.

KDLaccel_array = np.squeeze(np.array(KDLaccel))
time_array = np.squeeze(np.array(time))

### Writing to bag

rospack = rospkg.RosPack()

path = rospack.get_path('cw3_launch')
bag = rosbag.Bag(path + '/bags/q2abag_submit.bag', 'w')

time_data = Float64MultiArray()
time_data.data = time_array[:]
bag.write('Time', time_data)

accel_data = Float64MultiArray()
accel_data.data = KDLaccel_array[:,0]
bag.write('Joint_1', accel_data)

accel_data = Float64MultiArray()
accel_data.data = KDLaccel_array[:,1]
bag.write('Joint_2', accel_data)

accel_data = Float64MultiArray()
accel_data.data = KDLaccel_array[:,2]
bag.write('Joint_3', accel_data)

accel_data = Float64MultiArray()
accel_data.data = KDLaccel_array[:,3]
bag.write('Joint_4', accel_data)

accel_data = Float64MultiArray()
accel_data.data = KDLaccel_array[:,4]
bag.write('Joint_5', accel_data)

accel_data = Float64MultiArray()
accel_data.data = KDLaccel_array[:,5]
bag.write('Joint_6', accel_data)

accel_data = Float64MultiArray()
accel_data.data = KDLaccel_array[:,6]
bag.write('Joint_7', accel_data)

bag.close()

# plot_versus(GT_accel, KDLaccel, accel, time) # This can be uncommented to plot the comparison.