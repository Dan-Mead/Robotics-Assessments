#!/usr/bin/env python

from __future__ import division
import rospy
import rospkg
import rosbag
import sys
import numpy as np
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

from cw3q1.iiwa14Kine import iiwa14_kinematic
from kdl_kine.kdl_kine_solver import iiwa14KDL

iiwa = iiwa14_kinematic()
KDL = iiwa14KDL(2)

def callback(msg):

    """ This function mainly serves to simply pass recorded values outside of the loop."""

    pos = msg.position
    eff = msg.effort

    G = kdl_to_array(KDL.getG(pos))


    # Sign may be wrong here but the equations are consistent so answers are correct.
    tau_ext = eff - G

    time = rospy.get_time()

    if rospy.get_time() > 23.5 and rospy.get_time() < 24.5:
        telemetry = np.append((tau_ext), time)
        saved_values.append(telemetry)
        pos2 = np.append(pos, time)
        saved_pos.append(pos2)

    if rospy.get_time() > 43.5 and rospy.get_time() < 44.5:
        telemetry = np.append((tau_ext), time)
        saved_values.append(telemetry)
        pos2 = np.append(pos, time)
        saved_pos.append(pos2)

    if rospy.get_time() > 63.5 and rospy.get_time() < 64.5:
        telemetry = np.append((tau_ext), time)
        saved_values.append(telemetry)
        pos2 = np.append(pos, time)
        saved_pos.append(pos2)

    if rospy.get_time() > 66: # time until movement starts
        rospy.signal_shutdown('Test elapsed')

def kdl_to_mat(m):
    mat = np.array(np.zeros((m.rows(), m.columns())))
    for i in range(m.rows()):
        for j in range(m.columns()):
            mat[i,j] = m[i,j]
    return mat

def kdl_to_array(a):
    array = []
    for i in a:
        array.append(i)
    return np.array(array)

def calculations(values):

    """Defunct equations for solving for M and P_cm"""

    joint_sets = np.array([[90, -50, 100, 70, 0, 60, -30],[0, -35, 85, -60, 80, -60, 85],[-90, 52, 65, -65, 110, -110, -80]])

    ms = np.zeros([3,1])
    coms = np.zeros([3,3])

    for n in range(3):

        extract_values1 = []
        extract_values2 = []

        for j in values[:]:
            if j[-1] < (25 + n*20) and j[-1] > (15 + n*20):
                extract_values1.append(j[0])
                extract_values2.append(j[1])

        joints = joint_sets[n,:]

        final_joint_val = np.mean(extract_values1)
        penultimate_joint_val = np.mean(extract_values2)

        g = iiwa.g
        r_last = iiwa.forward_kine(joints, 7)[0:3,0]
        r_pen = iiwa.forward_kine(joints, 6)[0:3,0]

        l = np.linalg.norm((iiwa.forward_kine(joints, 7) - iiwa.forward_kine(joints, 6))[0:3,-1])

        K1 = np.dot(r_last, np.array([0, 0, -1])) / np.linalg.norm(r_last)
        theta1 = np.arccos(K1)

        K2 = np.dot(r_pen, np.array([0, 0, -1])) / np.linalg.norm(r_pen)
        theta2 = np.arccos(K2)

        MR_f = final_joint_val / (g * np.sin(theta1))
        MR_p = penultimate_joint_val / (g * np.sin(theta2))

        y = MR_p
        x = MR_f

        r = (x * l) / (y - x)

        m = x / r


        r_vec = r * (iiwa.forward_kine(joints, 7) - iiwa.forward_kine(joints, 6))[0:3,-1] / l

        ms[n] = m

        com = np.array([0, 0, r])

        coms[n,:] = com


    return ms, coms

def calculations2(values, positions):

    """ Function to calculate the mass and centre of mass given several sets of positions and values of E-G"""

    ### Initialise

    masses = np.zeros(3)
    translations = np.zeros([3,3])

    for n in range(3):

        ### Average the values taken, including recorded joint values

        joint_a_vals = []
        joint_b_vals = []
        joint_c_vals = []

        joint_set = np.zeros(7)

        ### Indexes of the joints used, here we use 2,4, and 6.

        a = 1
        b = 3
        c = 5 # Don't use i,j,k when you use them in for loops, idiot.

        for pos in positions[:]:
            if pos[-1] < (25 + n * 20) and pos[-1] > (15 + n * 20):
                joint_set = np.vstack((joint_set, pos[0:7]))

        for val in values[:]:
            if val[-1] < (25 + n * 20) and val[-1] > (15 + n * 20):
                joint_a_vals.append(val[a])
                joint_b_vals.append(val[b])
                joint_c_vals.append(val[c])

        joint_a_val = np.mean(joint_a_vals)
        joint_b_val = np.mean(joint_b_vals)
        joint_c_val = np.mean(joint_c_vals) # E - G
        joints = np.mean(joint_set[1:,:], axis = 0)

        ### Assign solutions

        A = joint_a_val
        B = joint_b_val
        C = joint_c_val

        ### Calculate values of the Jacobian

        T = np.identity(4)

        T[2, 3] = 0.1575

        Zs = [T[0:3, 2]]
        Ps = [T[0:3, 3]]

        for i in range(7):
            T = T.dot(iiwa.T_rotationZ(joints[i]))
            T = T.dot(iiwa.T_translation(iiwa.translation_vec[i, :]))
            T = T.dot(iiwa.T_rotationX(iiwa.X_alpha[i]))
            T = T.dot(iiwa.T_rotationY(iiwa.Y_alpha[i]))

            Zs.append(T[0:3, 2])
            Ps.append(T[0:3, 3])

        z11 = Zs[a][0]
        z12 = Zs[b][0]
        z13 = Zs[c][0]

        z21 = Zs[a][1]
        z22 = Zs[b][1]
        z23 = Zs[c][1]

        p11 = Ps[a][0]
        p12 = Ps[b][0]
        p13 = Ps[c][0]

        p21 = Ps[a][1]
        p22 = Ps[b][1]
        p23 = Ps[c][1]

        g = -1 * iiwa.g

        ### Solve using hideous equations.

        M = -(A*z12*z23 - A*z13*z22 - B*z11*z23 + B*z13*z21 + C*z11*z22 - C*z12*z21)/(g*(p11*z12*z21*z23 - p11*z13*z21*z22 - p21*z11*z12*z23 + p21*z11*z13*z22 - p12*z11*z22*z23 + p12*z13*z21*z22 + p22*z11*z12*z23 - p22*z12*z13*z21 + p13*z11*z22*z23 - p13*z12*z21*z23 - p23*z11*z13*z22 + p23*z12*z13*z21))

        X_pos = -(A*p12*z13*z22 - A*p22*z12*z13 - A*p13*z12*z23 + A*p23*z12*z13 - B*p11*z13*z21 + B*p21*z11*z13 + B*p13*z11*z23 - B*p23*z11*z13 + C*p11*z12*z21 - C*p21*z11*z12 - C*p12*z11*z22 + C*p22*z11*z12)/(A*z12*z23 - A*z13*z22 - B*z11*z23 + B*z13*z21 + C*z11*z22 - C*z12*z21)

        Y_pos = -(A*p12*z22*z23 - A*p22*z12*z23 - A*p13*z22*z23 + A*p23*z13*z22 - B*p11*z21*z23 + B*p21*z11*z23 + B*p13*z21*z23 - B*p23*z13*z21 + C*p11*z21*z22 - C*p21*z11*z22 - C*p12*z21*z22 + C*p22*z12*z21)/(A*z12*z23 - A*z13*z22 - B*z11*z23 + B*z13*z21 + C*z11*z22 - C*z12*z21)

        ### Project the vector out from the End Effector and solve

        position_vector = (iiwa.forward_kine(joints, 7) - iiwa.forward_kine(joints, 6))[0:3,-1]
        position_unit_vector = np.copy(position_vector / np.linalg.norm(position_vector))
        ee_loc = iiwa.forward_kine(joints, 7)[0:3,-1]


        x = np.copy((X_pos - ee_loc[0]) / position_unit_vector[0])
        y = np.copy((Y_pos - ee_loc[1]) / position_unit_vector[1])

        multiplier = np.mean(np.array([x,y]))

        Z_pos = ee_loc[2] + position_unit_vector[2] * multiplier

        P_cm = np.array([X_pos, Y_pos, Z_pos])

        distance_from_ee = np.transpose(np.atleast_2d(P_cm - ee_loc))

        final_rot = iiwa.forward_kine(joints, 7)[0:3,0:3]

        translation = np.transpose(np.matmul(np.linalg.inv(final_rot), distance_from_ee))

        translations[n,:] = translation[:]

        masses[n] = M

    ### Average over the configurations.

    final_mass = np.mean(masses)
    final_translations = np.mean(translations, axis = 0)

    return final_mass, final_translations

rospy.init_node('q2b_receiver')

start_time = rospy.get_time()
start_publish = 5
saved_values = []
saved_pos = []

sub = rospy.Subscriber('/object_iiwa/joint_states', JointState, callback)

rospy.spin()

length = len(saved_values)
values = np.zeros([length,8])
positions = np.zeros([length,8])
for i in range(length):
    values[i,:] = saved_values[i]
    positions[i,:] = saved_pos[i]

### Calculate values and 'publish'

mass, cm_translation = calculations2(values, positions)

rospy.loginfo('\n Mean Calculated Mass: {mass} \n Mean X Translation to CoM (End-Effector Frame): {x} \n Mean Y Translation to CoM (End-Effector Frame): \
{y} \n Mean Z Translation to CoM (End-Effector Frame): {z} \n Mean Distance from End-Effector to Centre of Mass: {dist} metres. \n'.format(mass = mass, x = cm_translation[0], y = cm_translation[1], z = cm_translation[2], dist = np.round(np.linalg.norm(cm_translation),3)))

### Values used for the extra arrangement, calculating the external torque.

joints_final = np.array([0, -90, -90, 90, -90, 90, -30]) * np.pi / 180

T = np.identity(4)

T[2, 3] = 0.1575

Zs = [T[0:3, 2]]
Ps = [T[0:3, 3]]

for i in range(7):
    T = T.dot(iiwa.T_rotationZ(joints_final[i]))
    T = T.dot(iiwa.T_translation(iiwa.translation_vec[i, :]))
    T = T.dot(iiwa.T_rotationX(iiwa.X_alpha[i]))
    T = T.dot(iiwa.T_rotationY(iiwa.Y_alpha[i]))

    Zs.append(T[0:3, 2])
    Ps.append(T[0:3, 3])

tau_ext = np.zeros(7)
Jp = np.zeros([3,7])

T_ee = iiwa.forward_kine(joints_final, 7)
T_cm = T_ee.dot(iiwa.T_translation(cm_translation))

P_cm = np.atleast_2d(T_cm[0:3,-1])

for i in range(7):
    Z = np.atleast_2d(Zs[i])
    P = np.atleast_2d(Ps[i])

    Jp[:, i] = np.cross(Z, (P_cm - P))

T_ext = (mass * np.matmul(np.array([0, 0, -1 * iiwa.g]), Jp))

rospy.loginfo('\n External Torque at requested configuration: {tau} \n'.format(tau = T_ext))

### THIS VALUE MAY BE NEGATIVE
### It is slightly unclear from the notes what the sign of T_ext should be her.
### Apologies if these values are negative. They should be of the correct magnitude regardless.
