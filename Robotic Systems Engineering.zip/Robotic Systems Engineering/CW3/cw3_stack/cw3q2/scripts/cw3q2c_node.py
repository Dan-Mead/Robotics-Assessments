#!/usr/bin/env python

from __future__ import division
import rospy
import rospkg
import rosbag
import sys
import numpy as np
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from cw3q1.iiwa14Kine import iiwa14_kinematic
from kdl_kine.kdl_kine_solver import iiwa14KDL

iiwa = iiwa14_kinematic()
KDL = iiwa14KDL(2)

def kdl_to_mat(m):
    mat = np.array(np.zeros((m.rows(), m.columns())))
    for i in range(m.rows()):
        for j in range(m.columns()):
            mat[i,j] = m[i,j]
    return mat

def kdl_to_array(a):
    array = []
    for i in a:
        array.append(i)
    return array

def callback(msg):

    """ Passes all telemetry values out fo the function."""

    pos = msg.position
    vel = msg.velocity
    eff = msg.effort

    KDLB = kdl_to_mat(KDL.getB(pos))
    KDLC = kdl_to_array(KDL.getC(pos, vel))
    KDLG = kdl_to_array(KDL.getG(pos))

    pos = np.array([pos])
    vel = np.array([vel])
    eff = np.array([eff])

    KDLB = np.squeeze(np.array([KDLB]))
    KDLC = np.array([KDLC])
    KDLG = np.array([KDLG])

    time.append(rospy.get_time() - start_time - publish_time)
    positions.append(pos)
    velocities.append(vel)
    efforts.append(eff)
    Bs.append(KDLB)
    Cs.append(KDLC)
    Gs.append(KDLG)


    if rospy.get_time() > start_time + publish_time + end_time: # time until movement starts
        rospy.signal_shutdown('Test elapsed')

def calculate_acceleration(time_array, velocities_array):

    """ Simple acceleration calculation using finite differences, outputs an nx7 array."""

    accelerations_array = np.zeros([length,7])

    for i in range(length-1):
        accelerations_array[i+1] = (velocities_array[i+1] - velocities_array[i])
        if (time_array[i+1] - time_array[i]) == 0:
            accelerations_array[i + 1] = accelerations_array[i]
        else:
            accelerations_array[i + 1] = accelerations_array[i+1]/ (time_array[i+1] - time_array[i])

    return accelerations_array

def calculate_tau_ext(positions_array):

    """Uses the formula in the Report to calculate tau_ext for each configuration recorded. Outputs an nx7 array."""

    tau_ext_array = np.zeros([length, 7])
    mass = 0.85
    cm_translation = np.array([0, 0, 0.15])

    for n in range(length):

        joints = positions_array[n]

        T = np.identity(4)

        T[2, 3] = 0.1575

        Zs = [T[0:3, 2]]
        Ps = [T[0:3, 3]]

        for i in range(7):
            T = T.dot(iiwa.T_rotationZ(joints[i]))
            T = T.dot(iiwa.T_translation(iiwa.translation_vec[i, :]))
            T = T.dot(iiwa.T_rotationX(iiwa.X_alpha[i]))
            T = T.dot(iiwa.T_rotationY(iiwa.Y_alpha[i]))

            Zs.append(T[0:3, 2])
            Ps.append(T[0:3, 3])

        Jp = np.zeros([3, 7])


        T_ee = iiwa.forward_kine(joints, 7)
        T_cm = T_ee.dot(iiwa.T_translation(cm_translation))

        P_cm = np.atleast_2d(T_cm[0:3, -1])

        for i in range(7):
            Z = np.atleast_2d(Zs[i])
            P = np.atleast_2d(Ps[i])

            Jp[:, i] = np.cross(Z, (P_cm - P))

        tau_ext_array[n,:] = mass * np.matmul(np.array([0, 0, -1 * iiwa.g]), Jp)
    return tau_ext_array

### Initialisation, unpacking, and publishing.

rospy.init_node('q2c_full_node')
pub = rospy.Publisher('/object_iiwa/EffortJointInterface_trajectory_controller/command', JointTrajectory, queue_size=10)
rate = rospy.Rate(10) # 10hz

joint_traj = JointTrajectory()

rospy.sleep(5)  # Change this if system does not load rviz etc. in time. Is fine on my laptop.

joint_traj.header.stamp = rospy.Time.now()
joint_traj.joint_names.append('object_iiwa_joint_1')
joint_traj.joint_names.append('object_iiwa_joint_2')
joint_traj.joint_names.append('object_iiwa_joint_3')
joint_traj.joint_names.append('object_iiwa_joint_4')
joint_traj.joint_names.append('object_iiwa_joint_5')
joint_traj.joint_names.append('object_iiwa_joint_6')
joint_traj.joint_names.append('object_iiwa_joint_7')

rospack = rospkg.RosPack()

path = rospack.get_path('cw3_launch')
bag = rosbag.Bag(path + '/bags/cw3bag2.bag')

publish_time = 5

time = 0

num_checkpoints = 4


for topic, msg, t in bag.read_messages(topics=['/iiwa/EffortJointInterface_trajectory_controller/command']):
    for i in range(num_checkpoints):
        time += + 10
        traj_point = JointTrajectoryPoint()
        traj_point.positions = msg.points[i].positions
        traj_point.velocities = msg.points[i].velocities
        traj_point.accelerations = msg.points[i].accelerations
        traj_point.time_from_start = rospy.Duration(time)
        joint_traj.points.append(traj_point)

bag.close()

end_time = num_checkpoints*10 + 1

pub.publish(joint_traj)

### Setting up values

start_time = rospy.get_time() - publish_time

time = []
positions = []
velocities = []
efforts = []
Bs = []
Cs = []
Gs = []

### Begin subscriber, end after set time.

sub = rospy.Subscriber('/object_iiwa/joint_states', JointState, callback)

rospy.spin()

### Converting the lists into usable data.

length = len(time)
time_array = np.zeros([length])
positions_array = np.zeros([length,7])
velocities_array = np.zeros([length,7])
efforts_array = np.zeros([length,7])
Bs_array = np.zeros([length,7,7])
Cs_array = np.zeros([length,7])
Gs_array = np.zeros([length,7])


for i in range(length):
    time_array[i] = time[i]
    positions_array[i,:] = positions[i]
    velocities_array[i,:] = velocities[i]
    efforts_array[i,:] = efforts[i]
    Bs_array[i,:,:] = Bs[i]
    Cs_array[i,:] = Cs[i]
    Gs_array[i,:] = Gs[i]

### Calculate additional values from available data

accelerations_array = calculate_acceleration(time_array, velocities_array)
tau_ext_array = calculate_tau_ext(positions_array)

tau_calc_array = np.zeros([length,7])

for n in range(length):
    tau_calc_array[n] = np.matmul(Bs_array[n],accelerations_array[n]) + Cs_array[n] + Gs_array[n] - tau_ext_array[n]

import matplotlib.pyplot as plt

### Reshape arrays for averaging (cuts off a few values from the end, no more than 10, not an issue in an array of many thousands)

cutoff = int(length/10)

time_array_av = np.zeros([cutoff])
tau_calc_array_av = np.zeros([cutoff, 7])
efforts_array_av = np.zeros([cutoff, 7])

time_array = time_array[0:cutoff*10]
tau_calc_array = tau_calc_array[0:cutoff*10,:]
efforts_array = efforts_array[0:cutoff*10,:]

time_array_av = np.mean(time_array.reshape(-1, 10), axis=1)

for n in range(7):
    tau_calc_array_av[:,n] = np.mean(tau_calc_array[:,n].reshape(-1, 10), axis=1)
    efforts_array_av[:,n] = np.mean(efforts_array[:,n].reshape(-1, 10), axis=1)

time_array = np.copy(time_array_av)
tau_calc_array = np.copy(tau_calc_array_av)
efforts_array = np.copy(efforts_array_av)

### Plot values

plt.subplot(121)

plt.title('Calculated Joint Torques')
plt.xlabel('Time')
plt.ylabel('Joint Torques')
plt.plot(time_array, tau_calc_array[:,0], label = 'Joint 1')
plt.plot(time_array, tau_calc_array[:,1], label = 'Joint 2')
plt.plot(time_array, tau_calc_array[:,2], label = 'Joint 3')
plt.plot(time_array, tau_calc_array[:,3], label = 'Joint 4')
plt.plot(time_array, tau_calc_array[:,4], label = 'Joint 5')
plt.plot(time_array, tau_calc_array[:,5], label = 'Joint 6')
plt.plot(time_array, tau_calc_array[:,6], label = 'Joint 7')
plt.legend()

plt.subplot(122)

plt.title('Recorded Joint Torques')
plt.xlabel('Time')
plt.ylabel('Joint Torques')
plt.plot(time_array, efforts_array[:,0], label = 'Joint 1')
plt.plot(time_array, efforts_array[:,1], label = 'Joint 2')
plt.plot(time_array, efforts_array[:,2], label = 'Joint 3')
plt.plot(time_array, efforts_array[:,3], label = 'Joint 4')
plt.plot(time_array, efforts_array[:,4], label = 'Joint 5')
plt.plot(time_array, efforts_array[:,5], label = 'Joint 6')
plt.plot(time_array, efforts_array[:,6], label = 'Joint 7')
plt.legend()

plt.show()



