from __future__ import division
import rospy
import rospkg
import rosbag
import sys
import numpy as np
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
from trajectory_msgs.msg import JointTrajectory

"""Test function for subscribing to babag.bag"""

rospack = rospkg.RosPack()

path = rospack.get_path('cw3_launch')
bag = rosbag.Bag(path + '/bags/q2abag_submit.bag')

for topic, msg, t in bag.read_messages(topics=['Time']):
    print msg.data

bag.close()
