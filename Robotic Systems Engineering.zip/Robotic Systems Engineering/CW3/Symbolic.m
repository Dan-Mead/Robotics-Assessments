g = sym('g');

z11 = sym('z11');
z12 = sym('z12');
z13 = sym('z13');
z14 = sym('z14');
z15 = sym('z15');
z16 = sym('z16');
z17 = sym('z17');

z21 = sym('z21');
z22 = sym('z22');
z23 = sym('z23');
z24 = sym('z24');
z25 = sym('z25');
z26 = sym('z26');
z27 = sym('z27');

z31 = sym('z31');
z32 = sym('z32');
z33 = sym('z33');
z34 = sym('z34');
z35 = sym('z35');
z36 = sym('z36');
z37 = sym('z37');

z = [0, z11, z12, z13, z14, z15, z16, z17; 0, z21, z22, z23, z24, z25, z26, z27; 1, z31, z32, z33, z34, z35, z36, z37];

p11 = sym('p11');
p12 = sym('p12');
p13 = sym('p13');
p14 = sym('p14');
p15 = sym('p15');
p16 = sym('p16');
p17 = sym('p17');

p21 = sym('p21');
p22 = sym('p22');
p23 = sym('p23');
p24 = sym('p24');
p25 = sym('p25');
p26 = sym('p26');
p27 = sym('p27');

p31 = sym('p31');
p32 = sym('p32');
p33 = sym('p33');
p34 = sym('p34');
p35 = sym('p35');
p36 = sym('p36');
p37 = sym('p37');
b = sym('base_offset');

p = [0, p11, p12, p13, p14, p15, p16, p17; 0, p21, p22, p23, p24, p25, p26, p27;  b, p31, p32, p33, p34, p35, p36, p37];

g_0 = [0, 0, -g];

p_cm_x = sym('pcmx');
p_cm_y = sym('pcmy');
p_cm_z = sym('pcmz');

p_cm = [p_cm_x; p_cm_y; p_cm_z];

J = [];

num_iter = 8;

for n = 1:num_iter
    z_i = z(:,n);
    p_i = p(:,n);
    
    T = cross(z_i, (p_cm - p_i));
    
    J = [J, T];
    
end

result = simplify(g_0 * J);

m = sym('m');

ja = m * simplify(result(2))
jb = m * simplify(result(3))
jc = m * simplify(result(4))

a_1 = z21*p11 - z11*p21;
a_2 = z21;
a_3 = z11;

b_1 = z22*p12 - z11*p22;
b_2 = z22;
b_3 = z12;

c_1 = z23*p13 - z13*p23;
c_2 = z23;
c_3 = z13;

syms M x y A B C

eqns = [ ja == A, jb == B, jc == C];


sol = solve(eqns, [m p_cm_x p_cm_y]);

M = simplify(sol.m);
X = simplify(sol.pcmx);
Y = simplify(sol.pcmy);

