There are 5 major sections in this submission:

   iiwa14Kine.py contains the class with all the required functions to make the simulations run. It is run by importing and being called.

   q2a.launch will run code for Q2a, this includes a publisher node, and the main node where the majority of the functionality is. The code will run until
   the simulation reaches roughly 40s, at which point it will write to the bag q2abag_submit.bag. The topics for this bag are 'Joint_i' where i is an
   integer from 1 to 7, and 'Time'. The values contained are acceleration values for the designated joint.

   q2b.launch will also run a publisher and main node. The code will run until roughly 66 seconds, staying stationary at the three checkpoints for roughly 10s each. It does
   not go to the fourth. After completion, this node outputs values to via a Ros Info print function, which should appear in the command line.

   q2c.launch will run only one node (I figured out they could be combined at about this stage). The simulation will run through all four configurations, and at the end will output
   a plot of the compared calculated and recorded effort values. This node may take some time to run due to the large number of calculations so please give it fair chance.

   q3.launch will run the entire simulation automatically. It is reccomended to add the line 'rviz:=true' if visualisation of checkpoints.


If any functions do not run, please try increasing sleep timers first (this may mess with some timings for some questions so do so with care); I can provide a working demonstration if
required.

A KDL package is also provided as it provides a slightly edited KDL_solver file which actually works with the provided files. A regular KDL solver will NOT work.

	
