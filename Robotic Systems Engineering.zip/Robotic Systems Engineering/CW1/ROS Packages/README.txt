The following packages have been provided as requested:

cw1q5
	Contains:
	cw1q5_node.py which should be run with some manner of request node to extract the data. One has been provided but simply compares predetermined values to test if the code is accurate. It should be run using rosrun or a launch file.
	cw1q5_req.py is an extra file. It can be run using rosrun as normal and offers a basic text prompt as to which test to run. All values are pre-determined in the code for easy reference to known transformations. 

cw1q5_srv
	Contains all the needed server nodes for cw1q5_node.py to function, these should not be adjusted.

cw1q6d
	Contains cw1q6d_node.py and cw1q6d _node.py (note the space, it is assumed to be a typo but both have been included, and have no difference in content). It is assumed and recommended this will be run through some manner of launch file similar to Example 01 from Lab 04,
	as running the code in isolation does nothing. The code also requires a XACRO file similar to the one for Q8 but more in line with the Simplified YouBot model where all axes can be constructed in 1D, this is for visualisation only,
	the transformations will still be accurate to the model regardless.
	To print transformations outside of the RVIZ environment, an additional node is required to subscribe to the transformations, or else the node can be told to print transformations manually in the code. This is not included in the package.
	
cw1q8b
	Similar to Q6, contains cw1q8b_node.py and cw1q8b _node.py (again, note the space, though content is identical). Again, the code runs without errors through rosrun but requires a more complex launch file to be meaningful. The XACRO file used has not been included as it is assumed
	the tester will have access. The code models the XACRO file with a small translation error due to a differing origin in the YouBot_arm_only XACRO URDF file, the code is set up assuming the base to be at the origin of a system.
	To print transformations outside of the RVIZ environment, an additional node is required to subscribe to the transformations, or else the node can be told to print transformations manually in the code. This is not included in the package.