#!/usr/bin/env python

import rospy
from math import pi
import numpy as np
from sensor_msgs.msg import JointState
from geometry_msgs.msg import TransformStamped, Quaternion
import tf2_ros

r = pi/180 # Conversion to radians

## Setting up D-H parameters as read from XACRO file.

# This is centered to the origin. If the base is not at the axis the first value should be altered to offset this.
# Eg. The base_link for the youbot_arm_only is at [- 0.024, 0, 0.030], meaning the values here will not quite align with the modelself.
# An offset of - 0.024 should be applied to the first index of a, and + 0.030 to the first index of d to account for this when comparing with this model.
# As this was not explicitly asked for in the coursework, the code has been left as though the base_link were at the origin.

a = [0.024, 0.033, 0.155, 0.135, 0.002, 0.0]
alpha = [0, -pi/2, 0.0, 0.0, pi/2, 0]
d = [0.096, 0.019, 0.0, 0.0, 0.0, 0.185]
theta = [0, 170*r, -65*r -pi/2, 146*r, -102.5*r + pi/2, 167.5*r]

## Names of Links which will be plotted.

name_link = ['arm8b_link0', 'arm8b_link1', 'arm8b_link2', 'arm8b_link3', 'arm8b_link4', 'arm8b_link5']

## Initialise Broadcaster

br = tf2_ros.TransformBroadcaster()

def forward_kinematic_standard(a, alpha, d, theta):

    ## Creating a basic transformation matrix used in F.K.

    A = np.zeros((4, 4))

    A[0, 0] = np.cos(theta)
    A[0, 1] = -np.sin(theta)*np.cos(alpha)
    A[0, 2] = np.sin(theta)*np.sin(alpha)
    A[0, 3] = a*np.cos(theta)

    A[1, 0] = np.sin(theta)
    A[1, 1] = np.cos(theta)*np.cos(alpha)
    A[1, 2] = -np.cos(theta)*np.sin(alpha)
    A[1, 3] = a*np.sin(theta)

    A[2, 1] = np.sin(alpha)
    A[2, 2] = np.cos(alpha)
    A[2, 3] = d

    A[3, 3] = 1.0

    return A


def rotmat2q(T):

    ## Conversion as transform message requires quarternions.

    q = Quaternion()

    angle = np.arccos((T[0, 0] + T[1, 1] + T[2, 2] - 1)/2)

    xr = T[2, 1] - T[1, 2]
    yr = T[0, 2] - T[2, 0]
    zr = T[1, 0] - T[0, 1]

    x = xr/np.sqrt(np.power(xr, 2) + np.power(yr, 2) + np.power(zr, 2))
    y = yr/np.sqrt(np.power(xr, 2) + np.power(yr, 2) + np.power(zr, 2))
    z = zr/np.sqrt(np.power(xr, 2) + np.power(yr, 2) + np.power(zr, 2))

    ## Zero rotations generate NAN errors so must account for and remove

    q.w = np.nan_to_num(np.cos(angle/2))
    q.x = np.nan_to_num(x * np.sin(angle/2))
    q.y = np.nan_to_num(y * np.sin(angle/2))
    q.z = np.nan_to_num(z * np.sin(angle/2))

    return q

def forward_kinematic(joint_msg):
    T = np.identity(4)

    transform = TransformStamped()

    ## Iterate over all frames.

    for i in range(len(a)):

        ## Account for negative axes of some joints (as given in the XACRO file)
        if i == 0:
            A = forward_kinematic_standard(a[i], alpha[i], d[i], theta[i])
        elif (i == 1) or (i == 5):
            A = forward_kinematic_standard(a[i], alpha[i], d[i], theta[i] - joint_msg.position[i-1])
        else:
            A = forward_kinematic_standard(a[i], alpha[i], d[i], theta[i] + joint_msg.position[i-1])

        transform.header.stamp = rospy.Time.now()
        transform.header.frame_id = 'base_link'
        transform.child_frame_id = name_link[i]

        ## Multiply transform forward

        T = T.dot(A)

        ## Convert to message

        transform.transform.translation.x = T[0, 3]
        transform.transform.translation.y = T[1, 3]
        transform.transform.translation.z = T[2, 3]
        transform.transform.rotation = rotmat2q(T)

        ## Publish message

        br.sendTransform(transform)

def main():
    rospy.init_node('forward_kinematic_node')
    sub = rospy.Subscriber('/joint_states', JointState, forward_kinematic)
    rate = rospy.Rate(10)
    rospy.spin()
    rate.sleep()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
