#!/usr/bin/env python

import rospy
import numpy as np
import math

from cw1q5_srv.srv import quat2zyx
from cw1q5_srv.srv import quat2zyxRequest

from cw1q5_srv.srv import quat2angleaxis
from cw1q5_srv.srv import quat2angleaxisRequest

from cw1q5_srv.srv import rotmat2quat
from cw1q5_srv.srv import rotmat2quatRequest

def conversion_client(i):

    if i == 1:

        rospy.wait_for_service('quat2zyx')

        while not rospy.is_shutdown():
            
            client = rospy.ServiceProxy('quat2zyx', quat2zyx)
            print 'Starting quat2zyx'
            req = quat2zyxRequest()

            ## Test Data

            q0 = 0.7071
            q1 = 0.7071
            q2 = 0
            q3 = 0

            req.q.w = q0
            req.q.x = q1
            req.q.y = q2
            req.q.z = q3

            resp = client(req)

            print 'The input'
            print req.q.w
            print req.q.x
            print req.q.y
            print req.q.z

            print 'The output'
            print 'z =', resp.z.data
            print 'y =', resp.y.data
            print 'x =', resp.x.data

    elif i == 2:

        rospy.wait_for_service('quat2angleaxis')

        while not rospy.is_shutdown():

            client = rospy.ServiceProxy('quat2angleaxis', quat2angleaxis)
            print 'Starting quat2angleaxis'
            req = quat2angleaxisRequest()

            ## Test Data

            q0 = 0.7071
            q1 = 0.7071
            q2 = 0
            q3 = 0

            req.q.w = q0
            req.q.x = q1
            req.q.y = q2
            req.q.z = q3

            resp = client(req)

            print 'The input'
            print req.q.w
            print req.q.x
            print req.q.y
            print req.q.z

            print 'The output'
            print 'x =', resp.x.data
            print 'y =', resp.y.data
            print 'z =', resp.z.data

    elif i == 3:

        rospy.wait_for_service('rotmat2quat')

        while not rospy.is_shutdown():

            client = rospy.ServiceProxy('rotmat2quat', rotmat2quat)
            print 'Starting rotmat2quat'
            req = rotmat2quatRequest()

            ## Test Data

            r1 = np.array([0, 0, 1])
            r2 = np.array([0, 1, 0])
            r3 = np.array([-1, 0, 0])

            req.r1.data = r1
            req.r2.data = r2
            req.r3.data = r3

            resp = client(req)

            print 'The input'
            print req.r1.data
            print req.r2.data
            print req.r3.data

            print 'The output'
            print 'x = ',resp.q.x
            print 'y = ',resp.q.y
            print 'z = ',resp.q.z
            print 'w = ',resp.q.w

    else:
        print 'Please enter a value from 1-3'

if __name__ == "__main__":
    try:
        i = input('Please choose node to run : \n 1: Quaternion to Euler \
        \n 2: Quarternion to Angle-Axis \n 3: Rotation Matrix to Quarternion')
        conversion_client(i)
    except rospy.ROSInterruptException:
        pass
