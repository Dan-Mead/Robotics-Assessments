#!/usr/bin/env python

import rospy
import numpy as np
import math

## Importing services


from cw1q5_srv.srv import quat2zyx
from cw1q5_srv.srv import quat2zyxResponse

from cw1q5_srv.srv import quat2angleaxis
from cw1q5_srv.srv import quat2angleaxisResponse

from cw1q5_srv.srv import rotmat2quat
from cw1q5_srv.srv import rotmat2quatResponse


def convert_quat2zyx(req):

    ## Conversions as given in Springer P. 14

    q0=req.q.w
    q1=req.q.x
    q2=req.q.y
    q3=req.q.z

    x = math.atan2(2*(q0*q1+q2*q3), 1 - 2*(q1**2 + q2**2))
    y = math.asin(2*(q0*q2 - q3*q1))
    z = math.atan2(2*(q0*q3 + q1*q2), 1 - 2*(q2**2 + q3**2))

    res = quat2zyxResponse()

    res.z.data = z
    res.y.data = y
    res.x.data = x

    return res

def convert_quat2angleaxis(req):

    ## Conversions as given in Springer P. 14

    q0=req.q.w
    q1=req.q.x
    q2=req.q.y
    q3=req.q.z

    theta = 2*math.acos(q0)
    x = q1/(math.sin(theta/2)) * theta
    y = q2/(math.sin(theta/2)) * theta
    z = q3/(math.sin(theta/2)) * theta

    res = quat2angleaxisResponse()

    res.z.data = z
    res.y.data = y
    res.x.data = x

    return res

def convert_rotmat2quat(req):

    ## Conversions as given in Springer P. 14

    r1 = req.r1.data
    r2 = req.r2.data
    r3 = req.r3.data

    q0 = 0.5 * np.sqrt(1 + r1[0] + r2[1] + r3[2])
    q1 = (r3[1] - r2[2]) / (4*q0)
    q2 = (r1[2] - r3[0]) / (4*q0)
    q3 = (r2[0] - r1[1]) / (4*q0)

    res = rotmat2quatResponse()

    res.q.w = q0
    res.q.x = q1
    res.q.y = q2
    res.q.z = q3

    return res

def rotation_converter():
    rospy.init_node('rotation_converter')

    ## Initialise the services

    s = rospy.Service('quat2zyx', quat2zyx, convert_quat2zyx)
    s1 = rospy.Service('quat2angleaxis', quat2angleaxis, convert_quat2angleaxis)
    s2 = rospy.Service('rotmat2quat', rotmat2quat, convert_rotmat2quat)

    rospy.spin()


if __name__ == "__main__":
    rotation_converter()
