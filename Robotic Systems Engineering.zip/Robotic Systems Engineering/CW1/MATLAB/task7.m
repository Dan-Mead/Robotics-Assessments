rad = pi/180;

% Regular Transforms

T1 = Transform(0, -pi/2, 0.147, 0);
T2 = Transform(0.155, 0, 0, 0 - pi/2);
T3 = Transform(0.135, 0, 0, 0);
T4 = Transform(0, pi/2, 0, 0 + pi/2);
T5 = Transform(0, 0, 0.218, 0);

% Transforms with error

T1E = Transform(0, -pi/2, 0.147, 0 + 1*rad);
T2E = Transform(0.155, 0, 0, 0 - pi/2 + 1*rad);
T4E = Transform(0, pi/2, 0, 0 + pi/2 + 1*rad);

% Substitute in for the correct value and location to add error.

TGT = T1*T2E*T3*T4*T5;

TES = T1*T2*T3*T4*T5;

% Calculate Error

TErr = inv(TGT) * TES;

% Display required values

Trans = (TErr(1:3, 4))

NormTrans = norm(Trans)

% Function to convert DH parameters to rotation matrices.

function T = Transform(a, alpha, d, theta)
    T = [cos(theta) -sin(theta)*cos(alpha) sin(theta)*sin(alpha) a*cos(theta);
        sin(theta) cos(theta)*cos(alpha) -cos(theta)*sin(alpha) a*sin(theta);
        0 sin(alpha) cos(alpha) d ;
        0 0 0 1];
end
