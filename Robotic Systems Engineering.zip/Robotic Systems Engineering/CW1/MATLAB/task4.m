R = [-sqrt(3)/4-sqrt(6)/8, -sqrt(2)/4, -3/4+sqrt(2)/8;...
    1/4-3*sqrt(2)/8, -sqrt(6)/4, sqrt(3)/4 + sqrt(6)/8;...
    -sqrt(6)/4, sqrt(2)/2, sqrt(2)/4]

beta = atan2(-R(3,1),sqrt(R(1,1)^2 + R(2,1)^2));

alpha = atan2(R(2,1)/cos(beta), R(1,1)/cos(beta));

gamma = atan2(R(3,2)/cos(beta), R(3,3)/cos(beta));


qw = 1/2 * sqrt(1 + R(1,1) + R(2,2) + R(3,3))

qx = (R(3,2) - R(2,3))/(4*qw)

qy = (R(1,3) - R(3,1))/(4*qw)

qz = (R(2,1) - R(1,2))/(4*qw)

quat = rotm2quat(R)