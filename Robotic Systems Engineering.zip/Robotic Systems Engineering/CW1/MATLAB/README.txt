This folder contains the code required for Matlab sections of various tasks.

All code should run automatically through Matlab. 

Task 1 was explicitly requested and was used to calculate condition numbers and the graph shown in Figure 1.

Task 4 was used in the calculation of various values including primarily atan2 values, it was not requested but has been included for completeness.

Task 7 was requested. The code will run but requires manual editing to return correct values. I.e. The transformations with error must be substituted into the correct equation 
*in the correct location* for the code to return the correct values.