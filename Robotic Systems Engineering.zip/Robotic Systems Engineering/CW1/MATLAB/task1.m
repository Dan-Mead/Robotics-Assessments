
%% Solving and Calculating Error

% Solve Ax = b for x

a1 = [1 2 -1; -2 1 -3; 0 1 3];

b1 = [-5 ; -10; 4];

a2 = [-5 4 -1; -4 1 -3; 11 1 10];

b2 = [-30; -13; 21];

% This is doable using inverses, either '\' function or 'mldivide' etc, but
% linsolve seems to work just as well.

x1 = linsolve(a1,b1);
x2 = linsolve(a2,b2);



% Array of standard deviations (sigma)

i = 0:0.001:0.01;

% Taking the mean of a set of data will be more accurate when working with
% random numbers. We will take 100 sets of data and average the errors.

errors1 = zeros(100, length(i));
errors2 = zeros(100, length(i));


for loop = 1:100
    
    % Formula for gaussian noise.
    noise = i .* randn(size(i));

    % All these are done using matlab's vector arithmetic

    b1_noise = b1 + noise;
    b2_noise = b2 + noise;

    x1_noise = linsolve(a1,b1_noise);
    x2_noise = linsolve(a2,b2_noise);

    % Calculate the norm of each difference

    error1 = vecnorm(x1 - x1_noise);
    error2 = vecnorm(x2 - x2_noise);
    
    errors1(loop,:) = error1;
    errors2(loop,:) = error2;

end

x = i;
y1 = mean(errors1);
y2 = mean(errors2);

% I now have an array of norms, which can be plotted against i.

%% Plotting

plot(x, y1, x, y2)

title('Error on solved linear equations with varying levels of noise')
xlabel('\sigma')
ylabel('Error')

% Condition numbers are useful for comparison and labelling.

lambda1 = eig(a1);
k1 = max(abs(lambda1)) / min(abs(lambda1));

lambda2 = eig(a2);
k2 = max(abs(lambda2)) / min(abs(lambda2));

legend({['\kappa(A) = ' num2str(k1)],['\kappa(B) = ' num2str(k2)]},'Location','northwest');





fprintf('\n')