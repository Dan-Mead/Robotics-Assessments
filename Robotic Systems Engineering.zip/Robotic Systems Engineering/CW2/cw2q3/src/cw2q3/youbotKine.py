#!/usr/bin/env python

import rospy
from math import pi
import numpy as np
import tf2_ros
from sensor_msgs.msg import JointState
from geometry_msgs.msg import TransformStamped, Quaternion
from trajectory_msgs.msg import JointTrajectory


class youbot_kinematic(object):

    def __init__(self):

        self.dh_params = [[-0.033, pi/2, 0.145, pi],
                          [0.155, 0.0, 0.0, pi/2],
                          [0.135, 0.0, 0.0, 0.0],
                          [-0.002, pi/2, 0.0, -pi/2],
                          [0.0, pi, -0.185, pi]]

        self.joint_offset = [170*pi/180, 65*pi/180, -146*pi/180, 102.5*pi/180, 167.5*pi/180]

        self.current_joint_position = [0.0, 0.0, 0.0, 0.0, 0.0]

        self.joint_limit_min = [-169*pi/180, -65*pi/180, -150*pi/180, -102.5*pi/180, -167.5*pi/180]
        self.joint_limit_max = [169*pi/180, 90*pi/180, 146*pi/180, 102.5*pi/180, 167.5*pi/180]

        self.joint_state_sub = rospy.Subscriber('/joint_states', JointState, self.joint_state_callback, queue_size=5)
        self.traj_publisher = rospy.Publisher('/EffortJointInterface_trajectory_controller/command', JointTrajectory, queue_size=5)

        self.pose_broadcaster = tf2_ros.TransformBroadcaster()

    def dh_matrix_standard(self, a, alpha, d, theta):
        A = np.zeros((4, 4))

        A[0, 0] = np.cos(theta)
        A[0, 1] = -np.sin(theta) * np.cos(alpha)
        A[0, 2] = np.sin(theta) * np.sin(alpha)
        A[0, 3] = a * np.cos(theta)

        A[1, 0] = np.sin(theta)
        A[1, 1] = np.cos(theta) * np.cos(alpha)
        A[1, 2] = -np.cos(theta) * np.sin(alpha)
        A[1, 3] = a * np.sin(theta)

        A[2, 1] = np.sin(alpha)
        A[2, 2] = np.cos(alpha)
        A[2, 3] = d

        A[3, 3] = 1.0

        return A


    def joint_state_callback(self, msg):
        for i in range(0, 5):
            self.current_joint_position[i] = msg.position[i]

        current_pose = self.forward_kine_offset(self.current_joint_position, 5)
        self.broadcast_pose(current_pose)


    def forward_kine(self, joint, frame):
        T = np.identity(4)

        for i in range(0, frame):
            A = self.dh_matrix_standard(self.dh_params[i][0], self.dh_params[i][1], self.dh_params[i][2], joint[i] + self.dh_params[i][3])

            T = T.dot(A)

        return T


    def forward_kine_offset(self, joint, frame):
        T = np.identity(4)

        for i in range(0, frame):
            if (i == 0):
                A = self.dh_matrix_standard(self.dh_params[i][0], self.dh_params[i][1], self.dh_params[i][2], self.joint_offset[i] - (joint[i] + self.dh_params[i][3]))
            else:
                A = self.dh_matrix_standard(self.dh_params[i][0], self.dh_params[i][1], self.dh_params[i][2], (joint[i] + self.dh_params[i][3]) - self.joint_offset[i])

            T = T.dot(A)

        return T


    def broadcast_pose(self, pose):

        transform = TransformStamped()

        transform.header.stamp = rospy.Time.now()
        transform.header.frame_id = 'base_link'
        transform.child_frame_id = 'arm_end_effector'

        transform.transform.translation.x = pose[0, 3]
        transform.transform.translation.y = pose[1, 3]
        transform.transform.translation.z = pose[2, 3]
        transform.transform.rotation = self.rotmat2q(pose)

        self.pose_broadcaster.sendTransform(transform)


    def rotmat2q(self, T):
        q = Quaternion()

        angle = np.arccos((T[0, 0] + T[1, 1] + T[2, 2] - 1) / 2)

        xr = T[2, 1] - T[1, 2]
        yr = T[0, 2] - T[2, 0]
        zr = T[1, 0] - T[0, 1]

        x = xr / np.sqrt(np.power(xr, 2) + np.power(yr, 2) + np.power(zr, 2))
        y = yr / np.sqrt(np.power(xr, 2) + np.power(yr, 2) + np.power(zr, 2))
        z = zr / np.sqrt(np.power(xr, 2) + np.power(yr, 2) + np.power(zr, 2))

        q.w = np.cos(angle / 2)
        q.x = x * np.sin(angle / 2)
        q.y = y * np.sin(angle / 2)
        q.z = z * np.sin(angle / 2)

        return q


    def q2rotmat(self, q):

        """Function required for making use of quarternions in Q4c"""

        e0 = q[0] #q.w
        e1 = q[1] #q.x
        e2 = q[2] #q.y
        e3 = q[3] #q.z

        R = np.eye(3)

        R[0,0] = 1 - 2*(e2*e2 + e3*e3)
        R[0,1] = 2*(e1*e2 - e0*e3)
        R[0,2] = 2*(e1*e3 + e0*e2)
        R[1,0] = 2*(e1*e2 + e0*e3)
        R[1,1] = 1 - 2*(e1*e1 + e3*e3)
        R[1,2] = 2*(e2*e3 - e0*e1)
        R[2,0] = 2*(e1*e3 - e0*e2)
        R[2,1] = 2*(e2*e3 + e0*e1)
        R[2,2] = 1 - 2*(e1*e1 + e2*e2)

        R[np.abs(R) < 1e-15] = 0

        return R


    def rotmat2pr(self, T):

        """Brief function to convert to poses for Jacobian calculation"""

        x = np.zeros([6])
        x[0:3] = T[0:3,-1]

        theta = np.arccos((T[0,0] + T[1,1] + T[2,2] - 1)/2)

        if theta == 0:
            x[3:6] = 0
        else:
            x[3] = (1/(2*np.sin(theta)))*(T[2,1] - T[1,2])
            x[4] = (1/(2*np.sin(theta)))*(T[0,2] - T[2,0])
            x[5] = (1/(2*np.sin(theta)))*(T[1,0] - T[0,1])

        return x


    def get_jacobian(self, joint):

        """Jacobian Calculation, all equations taken from lecture slides or Springer Handbook of Robotics"""


        n = len(self.dh_params)

        T = np.identity(4)
        Zs = [T[0:3, 2]]
        Ps = [T[0:3, 3]]

        for i in range(n): #check n here, should be 5

            A = self.dh_matrix_standard(self.dh_params[i][0], self.dh_params[i][1], self.dh_params[i][2],
                                        joint[i] + self.dh_params[i][3]) # Remember to add offsets when needed
            T = T.dot(A)

            Zs.append(T[0:3, 2])
            Ps.append(T[0:3, 3])

        J = np.zeros([6, n])
        Pe = Ps[-1]

        for i in range(n):

            Zi = Zs[i]
            Oi = Ps[i]

            Jp = np.cross(Zi, (Pe - Oi))
            Jo = Zi
            for k in range(3):
                J[k, i] = Jp[k]
                J[k + 3, i] = Jo[k]

        return J


    def get_jacobian_offset(self, joint):

        """Jacobian Used for the practical Youbot, as some DH parameters are different"""

        n = len(self.dh_params)

        T = np.identity(4)
        Zs = [T[0:3, 2]]
        Ps = [T[0:3, 3]]

        ### FK calculations are done manually as extracting data is needed per loop and calling the function would
        # result in a redundant For loop.

        for i in range(n):
            if (i == 0):
                A = self.dh_matrix_standard(self.dh_params[i][0], self.dh_params[i][1], self.dh_params[i][2], self.joint_offset[i] - (joint[i] + self.dh_params[i][3]))
            else:
                A = self.dh_matrix_standard(self.dh_params[i][0], self.dh_params[i][1], self.dh_params[i][2], (joint[i] + self.dh_params[i][3]) - self.joint_offset[i])
            T = T.dot(A)

            Zs.append(T[0:3, 2])
            Ps.append(T[0:3, 3])

        J = np.zeros([6, n])
        Pe = Ps[-1]

        for i in range(n):

            Zi = Zs[i]
            Oi = Ps[i]

            Jp = np.cross(Zi, (Pe - Oi))
            Jo = Zi
            for k in range(3):
                J[k, i] = Jp[k]
                J[k + 3, i] = Jo[k]

        return J

    def inverse_kine_closed_form(self, desired_pose):

        """Calculate 8 solutions based on the robot. Apparently this can be done in 4 solutions but this was not achieved."""

        ## Majority of this code (including some comments) taken from Lab 6,adjusted for this question.

        ##There are 8 possible inverse kinematic solutions. The last column indicates whether or not the solution lies within the robot workspace (does not exceed joint limit)
        inv_kine_sol = np.zeros((8, 6))

        a1 = self.dh_params[0][0]
        a2 = self.dh_params[1][0]
        a3 = self.dh_params[2][0]
        a4 = self.dh_params[3][0]

        d1 = self.dh_params[0][2]
        d5 = self.dh_params[4][2]

        ##Rename the variables so that the code is more readable.

        pose = desired_pose

        x = pose[0, 3]
        y = pose[1, 3]
        z = pose[2, 3]
        r13 = pose[0, 2]
        r23 = pose[1, 2]
        r31 = pose[2, 0]
        r32 = pose[2, 1]
        r33 = pose[2, 2]

        offsets = np.array(self.dh_params)[:,-1] * 1

        ##Solve for theta1
        inv_kine_sol[0, 0] = inv_kine_sol[1, 0] = inv_kine_sol[2, 0] = inv_kine_sol[3, 0] = np.arctan2(y, x) - offsets[0]

        ##Check with the joint limit for the other solution
        if (inv_kine_sol[0, 0] <= 0):
            inv_kine_sol[4, 0] = inv_kine_sol[5, 0] = inv_kine_sol[6, 0] = inv_kine_sol[7, 0] = np.arctan2(y, x) + pi - offsets[0]
        else:
            inv_kine_sol[4, 0] = inv_kine_sol[5, 0] = inv_kine_sol[6, 0] = inv_kine_sol[7, 0] = np.arctan2(y, x) - pi - offsets[0]

        k = K = 0

        ##Solve for theta3
        for i in range(0, 2):
            ##Rename the variables so that the code is more readable.
            th1_offset = inv_kine_sol[4 * i, 0] + offsets[0]

            if (np.cos(th1_offset) == 0):
                l = -r23 / np.sin(th1_offset)
                k = (y / np.sin(th1_offset)) - a1 - a4 * r33 - d5 * l

            else:
                l = -r13 / np.cos(th1_offset)
                k = (x / np.cos(th1_offset)) - a1 - a4 * r33 - d5 * l

            l = -r23 / np.sin(th1_offset)
            k = (y / np.sin(th1_offset)) - a1 - a4 * r33 - d5 * l

            z2 = z - d1 - a4*l + d5*r33

            K = k**2 + z2**2 - a2**2 - a3**2
            K = K / (2 * a2 * a3)

            ### If K is outside of the workspace, this returns an error. An approximation is to make K = +-1, this gives the
            # nearest value to what is required.

            while abs(K) > 1:

                K = K/abs(K)

            inv_kine_sol[4 * i, 2] = inv_kine_sol[4 * i + 1, 2] = np.arccos(K) - offsets[2]
            inv_kine_sol[4 * i + 2, 2] = inv_kine_sol[4 * i + 3, 2] = -np.arccos(K) - offsets[2]

            ##Rename the variables so that the code is more readable.
            th3_offset_1 = inv_kine_sol[4 * i, 2]  + offsets[2]
            th3_offset_2 = inv_kine_sol[4 * i + 2, 2]  + offsets[2]

            A1 = a2 + a3 * np.cos(th3_offset_1)
            A2 = a2 + a3 * np.cos(th3_offset_2)

            B1 = a3 * np.sin(th3_offset_1)
            B2 = a3 * np.sin(th3_offset_2)

            ##Rename the variables so that the code is more readable.
            gamma_1 = np.arctan2(B1, A1)
            gamma_2 = np.arctan2(B2, A2)

            ##Solve for theta2
            inv_kine_sol[4 * i, 1] = inv_kine_sol[4 * i + 1, 1] = np.arctan2(z2, k) - gamma_1 - offsets[1]
            inv_kine_sol[4 * i + 2, 1] = inv_kine_sol[4 * i + 3, 1] = np.arctan2(z2, k) - gamma_2 - offsets[1]


        for i in range(8):

            ##Solve for theta4

            th2_offset = inv_kine_sol[i, 1] + offsets[1]
            th3_offset = inv_kine_sol[i, 2] + offsets[2]

            if abs(r33) > 1:
                r33 = abs(r33) / r33 # Force this to be 1 to avoid bad solutions again.

            if (i % 2 == 0):
                inv_kine_sol[i, 3] = np.arccos(r33) - th2_offset - th3_offset - offsets[3]
            else:
                inv_kine_sol[i, 3] = -np.arccos(r33) - th2_offset - th3_offset - offsets[3]


            ##Rename the variables so the code is more readable.
            th4_offset = inv_kine_sol[i, 4] + offsets[3]

            ##Solve for theta5

            s = np.sin(th2_offset + th3_offset + th4_offset)

            inv_kine_sol[i, 4] = np.arctan2(r32/s, r31/s) - offsets[4] # atan2 doesn't mind dividing by zero apparently. Nice.


        #Check if the inverse kinematic solutions are in the robot workspace
        for i in range(0, 8):
            for j in range(0, 5):

                if (inv_kine_sol[i, j] <= self.joint_limit_min[j]) or (inv_kine_sol[i, j] >= self.joint_limit_max[j]):
                    ##If the solution is very close to the limit, it could be because of numerical error.

                    if (abs(inv_kine_sol[i, j] - self.joint_limit_min[j]) < 1.5 * pi / 180):
                        inv_kine_sol[i, j] = self.joint_limit_min[j]
                    elif (abs(inv_kine_sol[i, j] - self.joint_limit_max[j]) < 1.5 * pi / 180):
                        inv_kine_sol[i, j] = self.joint_limit_max[j]

                    ## Check to make sure solutions are 2pi out because of offsets or something.
                    elif inv_kine_sol[i, j] + 2 * pi < self.joint_limit_max[j]:
                        inv_kine_sol[i, j] += 2*pi
                        while inv_kine_sol[i, j] + 2 * pi < self.joint_limit_max[j]:
                            inv_kine_sol[i, j] += 2 * pi
                    elif inv_kine_sol[i, j] - 2 * pi > self.joint_limit_min[j]:
                        inv_kine_sol[i, j] -= 2 * pi
                        while inv_kine_sol[i, j] - 2 * pi > self.joint_limit_min[j]:
                            inv_kine_sol[i, j] -= 2 * pi

                    else:
                        ##Put some value there to let you know that this solution is not valid.
                        inv_kine_sol[i, 5] = -j
                        break
                else:
                    ##Put some value there to let you know that this solution is valid.
                    inv_kine_sol[i, 5] = 1

            ### Flag the solution as invalid if it represents a singularity

            if self.check_singularity(inv_kine_sol[i,0:-1]) == True:
                inv_kine_sol[i, 5] = -5

        return inv_kine_sol


    def inverse_kine_closed_form_offset(self, desired_pose):

        """This function is virtually identical to inverse_kine_closed_form except that the DH parameters take into account
        the construction of the YouBot and as such some values from FK equations have been adjusted. The same is done for offsets.
        This was required to get values that actualy worked in the simulator. Differing values are noted with a '#Change here' comment"""

        ## Majority of this code (including some comments) taken from Lab 6,adjusted for this question.

        ##There are 8 possible inverse kinematic solutions. The last column indicates whether or not the solution lies within the robot workspace (does not exceed joint limit)
        inv_kine_sol = np.zeros((8, 6))

        a1 = self.dh_params[0][0]
        a2 = self.dh_params[1][0]
        a3 = self.dh_params[2][0]
        a4 = self.dh_params[3][0]

        d1 = self.dh_params[0][2]
        d5 = self.dh_params[4][2]

        ##Rename the variables so that the code is more readable.

        pose = desired_pose

        x = pose[0, 3]
        y = - pose[1, 3] #Change here
        z = pose[2, 3]
        r13 = pose[0, 2]
        r23 = - pose[1, 2] #Change here
        r31 = pose[2, 0]
        r32 = pose[2, 1]
        r33 = pose[2, 2]

        offsets = np.array(self.dh_params)[:,-1]
        offsets[0] = -offsets[0] #Change here

        ##Solve for theta1
        inv_kine_sol[0, 0] = inv_kine_sol[1, 0] = inv_kine_sol[2, 0] = inv_kine_sol[3, 0] = np.arctan2(y, x) - offsets[0]

        ##Check with the joint limit for the other solution
        if (inv_kine_sol[0, 0] <= 0):
            inv_kine_sol[4, 0] = inv_kine_sol[5, 0] = inv_kine_sol[6, 0] = inv_kine_sol[7, 0] = np.arctan2(y, x) + pi - offsets[0]
        else:
            inv_kine_sol[4, 0] = inv_kine_sol[5, 0] = inv_kine_sol[6, 0] = inv_kine_sol[7, 0] = np.arctan2(y, x) - pi - offsets[0]

        k = K = 0

        ##Solve for theta3
        for i in range(0, 2):
            ##Rename the variables so that the code is more readable.
            th1_offset = inv_kine_sol[4 * i, 0] + offsets[0]

            if (np.cos(th1_offset) < np.sin(th1_offset)):
                l = -r23 / np.sin(th1_offset)
                k = (y / np.sin(th1_offset)) - a1 - a4 * r33 - d5 * l

            else:
                l = -r13 / np.cos(th1_offset)
                k = (x / np.cos(th1_offset)) - a1 - a4 * r33 - d5 * l


            z2 = z - d1 - a4*l + d5*r33

            K = k**2 + z2**2 - a2**2 - a3**2
            K = K / (2 * a2 * a3)


            while abs(K) > 1:

                K = K/abs(K)

            inv_kine_sol[4 * i, 2] = inv_kine_sol[4 * i + 1, 2] = np.arccos(K) - offsets[2]
            inv_kine_sol[4 * i + 2, 2] = inv_kine_sol[4 * i + 3, 2] = -np.arccos(K) - offsets[2]

            ##Rename the variables so that the code is more readable.
            th3_offset_1 = inv_kine_sol[4 * i, 2]  + offsets[2]
            th3_offset_2 = inv_kine_sol[4 * i + 2, 2]  + offsets[2]

            A1 = a2 + a3 * np.cos(th3_offset_1)
            A2 = a2 + a3 * np.cos(th3_offset_2)

            B1 = a3 * np.sin(th3_offset_1)
            B2 = a3 * np.sin(th3_offset_2)

            ##Rename the variables so that the code is more readable.
            gamma_1 = np.arctan2(B1, A1)
            gamma_2 = np.arctan2(B2, A2)

            ##Solve for theta2
            inv_kine_sol[4 * i, 1] = inv_kine_sol[4 * i + 1, 1] = np.arctan2(z2, k) - gamma_1 - offsets[1]
            inv_kine_sol[4 * i + 2, 1] = inv_kine_sol[4 * i + 3, 1] = np.arctan2(z2, k) - gamma_2 - offsets[1]


        for i in range(8):

            ##Solve for theta4

            th2_offset = inv_kine_sol[i, 1] + offsets[1]
            th3_offset = inv_kine_sol[i, 2] + offsets[2]

            if abs(r33) > 1:
                r33 = abs(r33) / r33 # Force this to be 1 to avoid bad solutions again.

            if (i % 2 == 0):
                inv_kine_sol[i, 3] = np.arccos(r33) - th2_offset - th3_offset - offsets[3]
            else:
                inv_kine_sol[i, 3] = -np.arccos(r33) - th2_offset - th3_offset - offsets[3]


            ##Rename the variables so the code is more readable.
            th4_offset = inv_kine_sol[i, 4] + offsets[3]

            ##Solve for theta5

            s = np.sin(th2_offset + th3_offset + th4_offset)

            inv_kine_sol[i, 4] = np.arctan2(r32/s, r31/s) - offsets[4] # atan2 doesn't mind dividing by zero apparently. Nice.


        #Check if the inverse kinematic solutions are in the robot workspace
        for i in range(0, 8):
            for j in range(0, 5):

                if (inv_kine_sol[i, j] <= self.joint_limit_min[j]) or (inv_kine_sol[i, j] >= self.joint_limit_max[j]):
                    ##If the solution is very close to the limit, it could be because of numerical error.

                    if (abs(inv_kine_sol[i, j] - self.joint_limit_min[j]) < 1.5 * pi / 180):
                        inv_kine_sol[i, j] = self.joint_limit_min[j]
                    elif (abs(inv_kine_sol[i, j] - self.joint_limit_max[j]) < 1.5 * pi / 180):
                        inv_kine_sol[i, j] = self.joint_limit_max[j]

                    ## Check to make sure solutions are 2pi out because of offsets or something.
                    elif inv_kine_sol[i, j] + 2 * pi < self.joint_limit_max[j]:
                        inv_kine_sol[i, j] += 2*pi
                        while inv_kine_sol[i, j] + 2 * pi < self.joint_limit_max[j]:
                            inv_kine_sol[i, j] += 2 * pi
                    elif inv_kine_sol[i, j] - 2 * pi > self.joint_limit_min[j]:
                        inv_kine_sol[i, j] -= 2 * pi
                        while inv_kine_sol[i, j] - 2 * pi > self.joint_limit_min[j]:
                            inv_kine_sol[i, j] -= 2 * pi

                    else:
                        ##Put some value there to let you know that this solution is not valid.
                        inv_kine_sol[i, 5] = -j
                        break
                else:
                    ##Put some value there to let you know that this solution is valid.
                    inv_kine_sol[i, 5] = 1

            if self.check_singularity(inv_kine_sol[i,0:-1]) == True:
                inv_kine_sol[i, 5] = -5

        ### It should be noted that, due to offsets in the hardware, it was simpler to apply these and check limits after
        # values were calculated. This makes this function in particular not constrained too much by checks, in fact they are
        # largely ignored at this stage, to be honest.

        return inv_kine_sol


    def inverse_kine_ite(self, desired_pose, current_joint):

        """Find a solution to a pose close to a given current joint via an iterative method. All equations are taken from
        lecture slides."""

        k = 0

        alpha = 0.01 # Margin of error for translational component
        beta = 1*np.pi/180 # Margin of error for rotational component
        gamma = 0.8 # Multiplier for the gradient descent. Ideally would make dynamic but did not have time to implement.
        q_k = current_joint
        p_end = self.rotmat2pr(desired_pose)
        p_q = self.rotmat2pr(self.forward_kine(q_k, len(q_k)))

        ### Loop while aim and calculated values are sufficiently different.

        while any((abs(diff) > alpha) for diff in (p_end - p_q)[0:3]) or any((abs(diff) > beta) for diff in (p_end - p_q)[3:6]):
            T_q = self.forward_kine(q_k, len(q_k))
            J_q = self.get_jacobian(q_k)
            p_q = self.rotmat2pr(T_q)
            q_k_old = q_k

            q_k = q_k + gamma * np.matmul(np.linalg.pinv(J_q), (p_end - p_q)) ### pinv or transpose can be used, with differing 'gammas'

            # # Check singularities, 'jump' over them if possible?
            # if self.check_singularity(q_k) == 1:
            #     q_k = q_k_old + 2 * gamma * np.matmul(np.linalg.pinv(J_q), (p_end - p_q))

            k += 1

            if all(abs(q_k_old - q_k)[0:3]) < alpha and all(abs(q_k_old - q_k)[3:6]) < beta:
                # If there is no improvement between iterations, stop calculating. Ideally the function would then be reinitialised fromm
                # a new point as this can only really happen if it is in a local minima which is not the solution.
                break
            if k >= 1000:
                # After a certain point, just stop.
                break

        ### Checks on joint limits.

        for i in range(len(q_k)):
            if q_k[i] < self.joint_limit_min[i] or q_k[i] > self.joint_limit_min[i]:
                if (abs(q_k[i] - self.joint_limit_min[i]) < 1.5 * pi / 180):
                    q_k[i] = self.joint_limit_min[i]
                elif (abs(q_k[i] - self.joint_limit_max[i]) < 1.5 * pi / 180):
                    q_k[i] = self.joint_limit_max[i]
                else:
                    q_k = np.append(q_k, 0)
                    break
            else:
                q_k = np.append(q_k, 1)

        ### Check if the solution is a singularity.

        if self.check_singularity(q_k) == 1:
            q_k = np.append(q_k, -1)

        return q_k


    def inverse_kine_ite_offset(self, desired_pose, current_joint):

        """Again, this is mainly used in practise, so the code is not as well documented, however the regular function was
        not geared for use with the offsets involved so some adjustments were made."""

        k = 0
        # offsets = np.array(self.joint_offset)
        alpha = 0.001 # Margin of error for translational component
        beta = 0.5*np.pi/180 # Margin of error for rotational component
        gamma = 0.0001
        q_k = np.array(current_joint)
        # q_k += offsets
        p_end = self.rotmat2pr(desired_pose)
        p_q = self.rotmat2pr(self.forward_kine_offset(q_k, len(q_k)))

        xyz = p_q[0:3]  ## Remove this
        qs = q_k  ## Remove this

        while any((abs(diff) > alpha) for diff in (p_end - p_q)[0:3]) or any((abs(diff) > beta) for diff in (p_end - p_q)[3:6]):
            T_q = self.forward_kine_offset(q_k, len(q_k))
            J_q = self.get_jacobian_offset(q_k)

            p_q = self.rotmat2pr(T_q)
            q_k_old = q_k

            q_k = q_k + gamma * np.matmul(np.linalg.pinv(J_q), (p_end - p_q))

            k += 1

            xyz = np.vstack((xyz, self.rotmat2pr(self.forward_kine_offset(q_k, len(q_k)))[0:3]))
            qs = np.vstack((qs, q_k))

            if all(abs(q_k_old - q_k)[0:3]) < 2*alpha and all(abs(q_k_old - q_k)[3:6]) < 2*beta:
                break
            ### In practise, speed is needed.
            if k >= 1000:
                print 'Maximum iterations reached.'
                break

        for i in range(len(q_k)):
            if q_k[i] < self.joint_limit_min[i] or q_k[i] > self.joint_limit_min[i]:
                if (abs(q_k[i] - self.joint_limit_min[i]) < 1.5 * pi / 180):
                    q_k[i] = self.joint_limit_min[i]
                elif (abs(q_k[i] - self.joint_limit_max[i]) < 1.5 * pi / 180):
                    q_k[i] = self.joint_limit_max[i]
                else:
                    q_k = np.append(q_k, 0)
                    break
            else:
                q_k = np.append(q_k, 1)

        if self.check_singularity(q_k) == 1:
            q_k = np.append(q_k, -1)

        ### Again, these checks were largely ignored in practise.

        return q_k


    def publish_joint_trajectory(self, joint_trajectory, tfs):
        """Publish the joint trajectory for use with the simulators. Honestly we couldn't figure out why you'd use tfs in this."""
        self.traj_publisher.publish(joint_trajectory)


    def check_singularity(self, current_joint):

        """ Check if a joint configuration represents a singularity. Used the determinant method rather than ranks. Function is
        used in both Closed Form and Iterative Implementation."""

        J = self.get_jacobian(current_joint)

        if J.shape[0] == J.shape[1]:
            J_test = J
        else:
            JT = np.transpose(J)
            J_test = np.matmul(JT,J)

        det = np.linalg.det(J_test)

        if det == 0:
            return True
        else:
            return False
