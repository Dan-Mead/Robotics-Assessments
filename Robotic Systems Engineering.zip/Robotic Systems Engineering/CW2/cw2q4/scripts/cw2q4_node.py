#!/usr/bin/env python

from __future__ import division
import rospy
import rosbag
import rospkg
import sys
import numpy as np
import scipy.linalg
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from cw2q3.youbotKine import youbot_kinematic
import itertools
import math

pi = np.pi

def main_traj(cw2data):

    ### Unpacking and initalising all data.

    rospy.init_node('youbot_traj_cw2', anonymous=True)

    my_youbot = youbot_kinematic()

    rospack = rospkg.RosPack()
    path = rospack.get_path('cw2q4')

    bag = rosbag.Bag(path + '/bags/data' + str(cw2data) + '.bag')

    joint_traj = JointTrajectory()

    ### Ros throws out errors if sleep isn't called. Here seemed to be the best location.

    rospy.sleep(5) # Change this if system does not load rviz etc. in time. Is fine on my laptop.

    joint_traj.header.stamp = rospy.Time.now()
    joint_traj.joint_names.append('arm_joint_1')
    joint_traj.joint_names.append('arm_joint_2')
    joint_traj.joint_names.append('arm_joint_3')
    joint_traj.joint_names.append('arm_joint_4')
    joint_traj.joint_names.append('arm_joint_5')

    ### Call a function based on input.

    if str(cw2data) == '1':
        q4a(bag, joint_traj, my_youbot)
    elif str(cw2data) == '2':
        q4b(bag, joint_traj, my_youbot)
    elif str(cw2data) == '3':
        q4c(bag, joint_traj, my_youbot)

    ### Publish joints.

    my_youbot.publish_joint_trajectory(joint_traj, 1)

def q4a(bag, joint_traj, my_youbot):

    """The arm must travel between a set of checkpoints, reaching them at a specified velocity and time."""

    ### Unpack and record joint configurations and required velocities.

    checkpoints = my_youbot.current_joint_position
    velocities = np.zeros(len(checkpoints))

    for topic, msg, t in bag.read_messages(topics=['joint_data']):
        checkpoints = np.vstack((checkpoints, msg.position))
        velocities = np.vstack((velocities, msg.velocity))

    bag.close()

    ### Create iterations.

    num_checkpoints = checkpoints.shape[0]
    checkpoint_dt = 10
    dt = 1
    num_iterations = checkpoint_dt / dt

    tfs = 0

    ### Calculation as given in the report, via a constrained polynomial split between checkpoints.

    for n in range(num_checkpoints - 1):

        ts = tfs
        tf = tfs + checkpoint_dt
        A = np.array([[1, ts, ts ** 2, ts ** 3],
                      [0, 1, 2 * ts, 3 * ts ** 2],
                      [1, tf, tf ** 2, tf ** 3],
                      [0, 1, 2 * tf, 3 * tf ** 2]])
        B = np.array([checkpoints[n], velocities[n], checkpoints[n + 1], velocities[n + 1]])
        X = np.linalg.solve(A, B) ### God bless numpy.

        a0 = X[0, :]
        a1 = X[1, :]
        a2 = X[2, :]
        a3 = X[3, :]

        for j in range(int(num_iterations)):
            current_point = JointTrajectoryPoint()
            tfs += dt
            current_point.positions = a0 + a1 * tfs + a2 * tfs ** 2 + a3 * tfs ** 3
            current_point.velocities = a1 + a2 * 2 * tfs + a3 * 3 * tfs ** 2
            current_point.time_from_start = rospy.Duration(tfs)
            joint_traj.points.append(current_point)


def q4b(bag, joint_traj, my_youbot):

    """ The robot arm should pass through the provided checkpoints in any order, attempting to find the shortest overall
    path for the end effector."""

    ### Initalise and unpack data.

    offsets = np.array(my_youbot.joint_offset)

    checkpoints = my_youbot.current_joint_position

    for topic, msg, t in bag.read_messages(topics=['joint_data']):
        checkpoints = np.vstack((checkpoints, msg.position))

    bag.close()

    num_checkpoints = checkpoints.shape[0]
    len_checkpoints = checkpoints.shape[1]

    Ts = np.ones([num_checkpoints, 4, 4])
    poses = np.ones([num_checkpoints,3])

    ### Calculate poses from checkpoints

    for n in range(num_checkpoints):
        Ts[n] = my_youbot.forward_kine_offset(checkpoints[n], len_checkpoints)
        poses[n] = Ts[n][0:3,-1]

    # Calculate the shortest travel path assuming linear travel is possible.

    x = np.arange(1,num_checkpoints)
    num_permutations = math.factorial(5)

    paths = np.zeros([num_permutations,num_checkpoints])
    distances = np.zeros(num_permutations)

    for n, i in enumerate(itertools.permutations(x,5)):
        paths[n, 1:] = i
        for k in range(num_checkpoints-1):
            start = int(paths[n][k])
            end = int(paths[n][k+1])
            start_pos = poses[start]
            end_pos = poses[end]
            distances[n] += np.linalg.norm(end_pos - start_pos)

    optimal_path = paths[np.argmin(distances)]

    ### Check for best path given joint limits mean theta1 >0 from start (was this intentional, makes it very difficult)
    
    first_point = int(optimal_path[1])
    last_point = int(optimal_path[-1])

    first = checkpoints[first_point][0]
    last = checkpoints[last_point][0]
    start = checkpoints[0][0]

    if (last - start) < (first - last):
        optimal_path = np.append(np.array(0),(np.flip(optimal_path[1:])))


    ### Reorder

    checkpoints_new = np.zeros(checkpoints.shape)

    for n in range(num_checkpoints):
        i = int(optimal_path[n])
        checkpoints_new[n] = checkpoints[i]

    # Find shortest route through checkpoints in joint angle space, effectively constraining interpolation.
    # Ideally shortest of all closed form solution permutations will be found.

    checkpoints_final = np.zeros(checkpoints_new.shape)
    checkpoints_final[0] = checkpoints_new[0]

    Transforms = np.zeros([num_checkpoints, 4 , 4])
    Transforms[0] = my_youbot.forward_kine_offset(checkpoints_final[0], 5)

    for check_num in range(1,num_checkpoints): # First checkpoint is set and constrained.

        last_joint = checkpoints_final[check_num-1]

        T = my_youbot.forward_kine_offset(checkpoints_new[check_num], len_checkpoints)
        aim_pos = T[0:3,-1]

        # Calculate closed-form solutions. All checkpoints must have at least one exact solution (the checkpoint parameters).

        solutions = my_youbot.inverse_kine_closed_form_offset(T)

        valid_solutions = []

        for solution_num in range(solutions.shape[0]):

            # Add offsets and check for 2pi rotations
            solutions[solution_num][0:-1] += offsets
            solutions[solution_num][0:-1] = check_limits_hardware(solutions[solution_num][0:-1])

            qs = solutions[solution_num][0:-1]
            got_pos = my_youbot.forward_kine_offset(qs, len_checkpoints)[0:3, -1]

            diff = got_pos - aim_pos

            if np.allclose(got_pos, aim_pos, 1e-6) == True:
                valid_solutions = np.append(valid_solutions, qs).reshape((-1, 5))

        # If no valid solutions (there shouldn't be) then just use the checkpoint values.

        if len(valid_solutions) == 0:
            checkpoints_final[check_num] = checkpoints_new[check_num]

        # Else find the checkpoint values closest to the previous joint values.

        else:
            norms = np.zeros([valid_solutions.shape[0], 1])
            for j in range(valid_solutions.shape[0]):
                norms[j] = np.linalg.norm((valid_solutions[j] - last_joint) * np.array([2,1,1,1,1])) # Give extra weighting to the first joint, biggest source of motion.

            checkpoints_final[check_num] = valid_solutions[np.argmin(norms)]

        Transforms[check_num] = my_youbot.forward_kine_offset(checkpoints_final[check_num], 5)

    ### Interpolate points and find closest solutions


    time = 0
    num_iterations = 5 # More iterations gives a more linear result but can become unstable.
    checkpoint_dt = 20

    start = my_youbot.current_joint_position

    # Publish the first points

    current_point = JointTrajectoryPoint()
    current_point.positions = start
    current_point.time_from_start = rospy.Duration(time)
    joint_traj.points.append(current_point)

    last_joint = start

    # Don't iterate over the last point as values are projected forward.

    for check_num in range(0,num_checkpoints-1):

        print 'Checkpoint', check_num, '-', check_num + 1 # Remove

        T_start = Transforms[check_num]
        T_finish = Transforms[check_num + 1]

        ps = T_start[0:3,-1]
        pf = T_finish[0:3,-1]

        Rs = T_start[0:3,0:3]
        Rf = T_finish[0:3,0:3]

        # Interpolate between 0 and 1, as given in lecture notes.

        for t in np.linspace(1 / num_iterations, 1, num_iterations):

            pt = ps + t * (pf - ps)

            a = np.matmul(np.linalg.inv(Rs), Rf)
            b = t * scipy.linalg.logm(a)
            Rt = np.matmul(Rs, scipy.linalg.expm(b))

            input_transform = np.eye(4)
            input_transform[0:3,0:3] = Rt
            input_transform[0:3,-1] = pt

            solutions = my_youbot.inverse_kine_closed_form_offset(input_transform)

            valid_solutions = []
            close_solutions = []

            for solution_num in range(solutions.shape[0]):

                # Add offsets and check for 2pi rotations

                solutions[solution_num][0:-1] += offsets
                solutions[solution_num][0:-1] = check_limits_hardware(solutions[solution_num][0:-1])

                qs = solutions[solution_num][0:-1]
                got_pos = my_youbot.forward_kine_offset(qs, len_checkpoints)[0:3,-1]
                diff = abs(pt - got_pos)

                if np.allclose(got_pos, pt, 1e-16) == True:
                    valid_solutions = np.append(valid_solutions,qs).reshape((-1,5))

                if t < 1.0: # Only need very close solutions for checkpoints, otherwise a reasonable margin is acceptable.
                    if all(x < 0.05 for x in diff) == True: ### This is fairly generous but can afford to be, an approximation of a straight line
                        close_solutions = np.append(close_solutions, qs).reshape((-1, 5))

            if len(valid_solutions) > 0:
                print 'Exact solution' # Remove
                norms = np.zeros([valid_solutions.shape[0], 1])

                for j in range(valid_solutions.shape[0]):
                    norms[j] += np.linalg.norm((valid_solutions[j] - last_joint)*np.array([2,1,1,1,1]))

                joint_solution = valid_solutions[np.argmin(norms)]


            elif len(close_solutions) > 0:
                print 'Close solution' # Remove
                norms = np.zeros([close_solutions.shape[0], 1])

                for j in range(close_solutions.shape[0]):
                    norms[j] += np.linalg.norm((close_solutions[j] - last_joint)*np.array([2,1,1,1,1]))

                joint_solution = close_solutions[np.argmin(norms)]

            else:
                # Full disclosure - this doesn't curently work properly. Implementation is largely theoretical

                print 'Iterative Solution' # Remove

                current_joint_values = last_joint
                joint_solution = my_youbot.inverse_kine_ite_offset(input_transform, current_joint_values)[0:-1]
                joint_solution = check_limits_hardware(joint_solution)


            last_joint = joint_solution
            if num_iterations < 5:
                time += 5 # Should give enough time for the robot to reach any pose. Can reduce for more iterations.
            else:
                time += checkpoint_dt/num_iterations

            current_point = JointTrajectoryPoint()
            current_point.positions = joint_solution
            current_point.time_from_start = rospy.Duration(time)
            joint_traj.points.append(current_point)

            print check_num, np.round(t,2), joint_solution, time + 5, '\n' # Remove

            my_youbot.publish_joint_trajectory(joint_traj, 1) # If using iterative, it can be beneficial to publish redundantly here.

def q4c(bag, joint_traj, my_youbot):

    """ The robot arm should pass through provided checkpoints in any order, avoiding obstacles."""

    offsets = my_youbot.joint_offset

    start = my_youbot.current_joint_position

    num_joints = len(start)

    poses = np.array([my_youbot.forward_kine_offset(start, num_joints)])

    for topic, msg, t in bag.read_messages(topics=['target_position']):

        px = msg.translation.x
        py = msg.translation.y
        pz = msg.translation.z
        q = msg.rotation

        T = np.eye(4)

        rotmat = my_youbot.q2rotmat([q.w,q.x,q.y,q.z])
        pos = np.array([px,py,pz])

        T[0:3,0:3] = rotmat
        T[0:3,-1] = pos

        poses = np.concatenate((poses, np.array([T])), axis = 0)

    num_checkpoints = poses.shape[0]


    checkpoints = np.zeros([num_checkpoints,5])

    ### Find shortest route between points

    x = np.arange(1, num_checkpoints)
    num_permutations = math.factorial(5)

    paths = np.zeros([num_permutations, num_checkpoints])
    distances = np.zeros(num_permutations)

    for n, i in enumerate(itertools.permutations(x, 5)):
        paths[n, 1:] = i
        for k in range(num_checkpoints - 1):
            start = int(paths[n][k])
            end = int(paths[n][k + 1])
            start_pos = poses[start]
            end_pos = poses[end]
            distances[n] += np.linalg.norm(end_pos - start_pos)

    optimal_path = paths[np.argmin(distances)]

    poses_new = np.zeros(poses.shape)
    for n in range(num_checkpoints):
        i = int(optimal_path[n])
        poses_new[n] = poses[i]

    ### Solve for shortest solution

    last_joint = my_youbot.current_joint_position

    start = np.zeros([5])

    for check_num in range(1, num_checkpoints):
        T = poses_new[check_num]
        pos = T[0:3,-1]
        solutions = my_youbot.inverse_kine_closed_form_offset(T)
        valid_solutions = []
        for j in range(solutions.shape[0]):
            q = solutions[j][0:-1] + offsets
            q = check_limits_hardware(q)
            got_pos = my_youbot.forward_kine_offset(q, 5)[0:3,-1]
            if np.allclose(got_pos, pos, 1e-6) == True:
                valid_solutions = np.append(valid_solutions,q).reshape((-1,5))
                # print valid_solutions

        norms = np.zeros([valid_solutions.shape[0], 1])
        for n, sol in enumerate(valid_solutions[:]):
            norms[n] = np.linalg.norm(sol - last_joint) # Closest to start

        joint_solution = valid_solutions[np.argmin(norms)]

        checkpoints[check_num] = joint_solution

        last_joint = joint_solution

    ### Reorder to shortest rotational route

    reorder = np.argsort(checkpoints[:,0])

    checkpoints_new = np.zeros(checkpoints.shape)

    for n, i in enumerate(reorder):
        checkpoints_new[n] = checkpoints[i]

    ### Model Obstacles as potential repulsors, checkpoints as potential attractors
    len_checkpoints = checkpoints_new.shape[1]

    # Get location of each joint

    current_joints = np.copy(checkpoints_new[1])  #Example for test
    aimed_joints = np.copy(checkpoints_new[2]) #Example for test

    box_pos = [-0.314882, -0.161619, 0.099055, 6e-06, -4e-06, 0.002076]
    box_size = [0.194033, 0.077038, 0.19811]

    cyl0_pos = [-0.328049, 0.226524, 0.041954, 0, -0, 0.004138]
    cyl0_size = [0.099549, 0.099549, 0.083927]

    cyl1_pos = [0.31751, 0.06442, 0.069553, 0, -0, 0]
    cyl1_size = [0.128675, 0.128675, 0.139125]

    ### Currently modelling obstacles as spheres, for ease of calculation. all values are placeholders

    box_width = max(box_size)
    cyl0_width = max(cyl0_size)
    cyl1_width = max(cyl1_size)


    zeta = np.ones(len_checkpoints)
    eta = np.ones(len_checkpoints)
    min_dist_att = 0.1
    min_dist_rep = 0.1#
    eta_threshold = 1
    alpha_k = 0.1

    jacobian = my_youbot.get_jacobian_offset(current_joints)

    for joint_num in range(len_checkpoints):

        joint_loc = my_youbot.forward_kine_offset(current_joints, joint_num)[0:3,-1]

        joint_aim = my_youbot.forward_kine_offset(aimed_joints, joint_num)[0:3,-1]

        diff = joint_loc - joint_aim

        # Calculate attractive forces

        if np.linalg.norm(diff) <= min_dist_att:
            F_att = - zeta[joint_num] * diff
        else:
            F_att = - min_dist_att * zeta[joint_num] * (diff / np.linalg.norm(diff))

        # Calculate Repulsive Forces

        box_dist = joint_loc - box_pos[0:3] - box_width # Needs changing once spherical model is updated.
        cyl0_dist = joint_loc - cyl0_pos[0:3] - cyl0_width
        cyl1_dist = joint_loc - cyl1_pos[0:3] - cyl1_width

        closest_ob_arg = np.argmin([np.linalg.norm(box_dist), np.linalg.norm(cyl0_dist), np.linalg.norm(cyl1_dist)])
        closest_ob_dist = np.array([box_dist, cyl0_dist, cyl1_dist])[closest_ob_arg]


        for dist in [box_dist, cyl0_dist, cyl1_dist]:
            F_rep = eta[joint_num] * (1 / dist - 1 / min_dist_rep)**2
            F_rep = F_rep / dist * closest_ob_dist/np.linalg.norm(closest_ob_dist)

        t_att = np.matmul(jacobian[0:3,joint_num], F_att)
        t_rep = np.matmul(jacobian[0:3,joint_num], F_rep)

        torque = t_att + t_rep

        while current_joints[joint_num] - aimed_joints[joint_num] < eta_threshold:
            k += 1
            current_joints[joint_num] = current_joints[joint_num] + alpha_k * torque/np.linalg.norm(torque)

            if k >= 1000:
                break

        ### Sadly could not implement any further, ran out of time.
        # Will implement manual planning from here.



    ### Manual path planning based on visual inspection, will update with field work if time allows.

    time = 5

    for n in range(0, num_checkpoints):

        joint = checkpoints_new[n]

        joint = check_limits_hardware(joint)

        prep = np.copy(start)

        prep[0] = joint[0]

        ### Return to centre each time, largely avoids obstacles. except the last one which may be a bug?

        time += 5
        current_point = JointTrajectoryPoint()
        current_point.positions = prep
        current_point.time_from_start = rospy.Duration(time)
        joint_traj.points.append(current_point)

        time += 5
        current_point = JointTrajectoryPoint()
        current_point.positions = joint
        current_point.time_from_start = rospy.Duration(time)
        joint_traj.points.append(current_point)

        time += 5

        current_point = JointTrajectoryPoint()
        current_point.positions = prep
        current_point.time_from_start = rospy.Duration(time)
        joint_traj.points.append(current_point)


def check_limits_hardware(joints):

    """ Simple function which calculates if values are within the actual joint limits of the robot and adjusts accordingly."""

    my_youbot = youbot_kinematic()

    min = np.array(my_youbot.joint_limit_min)
    max = np.array(my_youbot.joint_limit_max)
    offsets = np.array(my_youbot.joint_offset)
    min_offset = min + offsets
    max_offset = max + offsets
    for n, j in enumerate(joints):

        while joints[n] < min_offset[n]:
            joints[n] += 2*pi
        while joints[n] > max_offset[n]:
            joints[n] -= 2*pi

    return joints


if __name__ == '__main__':
    try:
        main_traj(sys.argv[1])
    except rospy.ROSInterruptException:
        pass
