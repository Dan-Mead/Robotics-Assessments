a1 = sym('a1');
a2 = sym('a2');
a3 = sym('a3');
a4 = sym('a4');
d1 = sym('d1');
d5 = sym('d5');
th1 = sym('th1');
th2 = sym('th2');
th3 = sym('th3');
th4 = sym('th4');
th5 = sym('th5');

%th1 + pi
%th2 + pi/2
%th4 - pi/2
%th5 -pi

DH = [a1    pi/2   d1   -th1; 
      a2    0      0    th2; 
      a3    0      0    th3; 
      a4    pi/2   0    th4; 
      0     pi     d5   th5];

Te = eye(4);
  
for i = 1 : length(DH(:,1))

    a = DH(i,1);
    alpha = DH(i,2);
    d = DH(i,3);
    theta = DH(i,4);
    
    T = Transform(a, alpha, d, theta);
    
    Te = Te*T;
end

r11 = simplify(Te(1,1));
r12 = simplify(Te(1,2));
r13 = simplify(Te(1,3));
x   = simplify(Te(1,4));
r21 = simplify(Te(2,1));
r22 = simplify(Te(2,2));
r23 = simplify(Te(2,3));
y   = simplify(Te(2,4));
r31 = simplify(Te(3,1));
r32 = simplify(Te(3,2));
r33 = simplify(Te(3,3));
z   = simplify(Te(3,4));
r41 = simplify(Te(4,1));
r42 = simplify(Te(4,2));
r43 = simplify(Te(4,3));
r44 = simplify(Te(4,4));

x
y
z

r11
r12
r13
r21
r22
r23
r31
r32
r33

x2 = simplify(x/cos(th1) - a1 - a4*r33 - d5 *sin(th2 + th3 + th4));
y2 = simplify(y/sin(th1) - a1 - a4*r33 - d5 *sin(th2 + th3 + th4));
z2 = simplify(z + d5 * r33 - d1 - a4 * sin(th2+th3+th4));

theta1 = simplify(atan(r23/r13)); % Check other solutions
theta5 = simplify(atan(r32/r31)); % Check other solutions

test = simplify((z2^2 + x2^2- a2^2 - a3^2)/(2*a2*a3));

theta3 = simplify(acos((x2^2 + z2^2 -a2^2 - a3^2) / (2* a2 * a3)));

E = simplify(a2 + a3 * cos(th3));
F = simplify(a3 * sin(th3));

z3 = simplify(sin(th2) * E + cos(th2) * F);
x3 = simplify(cos(th2) * E - sin(th2) * F);

theta2 = simplify(atan2(z3,x3) - atan2(F,E));

theta4 = acos(r33) - th2 - th3;

simplify(sqrt(x^2+y^2))

function T = Transform(a, alpha, d, theta)
    T = [cos(theta) -sin(theta)*cos(alpha) sin(theta)*sin(alpha) a*cos(theta);
        sin(theta) cos(theta)*cos(alpha) -cos(theta)*sin(alpha) a*sin(theta);
        0 sin(alpha) cos(alpha) d ;
        0 0 0 1];
end
