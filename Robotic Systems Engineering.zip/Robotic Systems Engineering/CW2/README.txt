No special instructions are needed to run this code. Q3 requires the class to be initialised and then functions can be run/tested independently.

Q4 requires the appropriate function to be called via. input argument. String, float, or integer is not important. 
Ideally it will be run with a launch file, an example of such a command is:
	'roslaunch cw2q4 cw2q4py.launch question:=1' (without quotes)
	rviz:=false or gui:=false can be used to disable activation of either rviz or gazebo.

The matlab file shows how equations were calculated making extensive use of the simplify term. The file is currently set up to examine what parameters changed given the YouBot's offsets. The file was
used to calculate the equations only, all other work was done by hand, with a few values being corroborated, as seen in the code.

At the time of writing, all code runs given these commands, and requires no debugging.